#!/bin/sh
# Lance Kami-heim avec Docker puis ouvre le navigateur
cd "$(dirname "$0")" || exit 1
docker compose up -d --build || { echo "Échec du démarrage. Docker est-il lancé ?"; exit 1; }
sleep 3
URL="http://localhost:${KAMIHEIM_PORT:-8080}"
if command -v xdg-open >/dev/null 2>&1; then xdg-open "$URL"; elif command -v open >/dev/null 2>&1; then open "$URL"; else echo "Ouvrez $URL"; fi
