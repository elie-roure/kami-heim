export const EXPENSE_CATEGORIES = {
  copropriete: 'Charges de copropriété (syndic)',
  taxe_fonciere: 'Taxe foncière',
  taxe_habitation: "Taxe d'habitation",
  teom: "Taxe d'enlèvement des ordures ménagères",
  assurance_pno: 'Assurance propriétaire non occupant',
  travaux: 'Travaux / entretien',
  energie: 'Eau / énergie',
  gestion: 'Frais de gestion / agence',
  frais_bancaires: 'Frais bancaires',
  comptabilite: 'Comptabilité / déclarations',
  autre: 'Autre',
};

export const categoryLabel = (key) => EXPENSE_CATEGORIES[key] || key;

export const DOCUMENT_CATEGORIES = {
  bail: 'Bail / avenant',
  etat_des_lieux: 'État des lieux',
  identite: "Pièce d'identité",
  revenus: 'Justificatifs de revenus',
  garant: 'Garant / caution',
  assurance: "Attestation d'assurance",
  diagnostic: 'Diagnostics',
  syndic: 'Syndic / copropriété',
  impots: 'Impôts / taxes',
  pret: 'Prêt bancaire',
  facture: 'Factures / travaux',
  courrier: 'Courriers',
  autre: 'Autre',
};

export const PAYMENT_METHODS = ['Virement', 'Prélèvement', 'Chèque', 'Espèces', 'CAF / APL', 'Autre'];
