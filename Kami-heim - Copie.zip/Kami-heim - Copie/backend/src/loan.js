import { addMonths, num, pad2, round2 } from './util.js';

/** Constant-payment amortization schedule (standard French "prêt amortissable"). */
export function computeSchedule({ principal, annual_rate, duration_months, start_date, insurance_monthly = 0 }) {
  const n = Math.trunc(duration_months);
  if (!(principal > 0) || !(n > 0) || !start_date) return [];
  const r = (annual_rate || 0) / 100 / 12;
  const payment = r === 0 ? principal / n : (principal * r) / (1 - Math.pow(1 + r, -n));
  const insurance = round2(insurance_monthly || 0);
  const rows = [];
  let remaining = principal;
  for (let i = 1; i <= n; i++) {
    const interest = round2(remaining * r);
    let capital = i === n ? round2(remaining) : round2(payment - interest);
    if (capital > remaining) capital = round2(remaining);
    remaining = round2(remaining - capital);
    rows.push({
      number: i,
      due_date: addMonths(start_date, i - 1),
      principal: capital,
      interest,
      insurance,
      payment: round2(capital + interest + insurance),
      remaining,
    });
  }
  return rows;
}

const normalizeHeader = (h) =>
  h
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');

function detectColumn(header) {
  const h = normalizeHeader(header);
  if (!h) return null;
  if (h.includes('restant') || h.includes('crd') || h.includes('capitaldu') || h.includes('soldedu')) return 'remaining';
  if (h.includes('date')) return 'due_date';
  if (h.includes('interet')) return 'interest';
  if (h.includes('assurance')) return 'insurance';
  if (h.includes('mensualite') || h.includes('montant') || h.includes('total') || h === 'echeancetotale') return 'payment';
  if (h.includes('capital') || h.includes('amortissement') || h.includes('amorti')) return 'principal';
  if (['n', 'no', 'num', 'numero', 'echeance', 'rang', 'periode', 'ndecheance', 'nech', 'numecheance'].includes(h) || h.startsWith('numero')) {
    return 'number';
  }
  return null;
}

function parseDate(value) {
  const v = String(value || '').trim();
  let m = v.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (m) return `${m[1]}-${pad2(m[2])}-${pad2(m[3])}`;
  m = v.match(/^(\d{1,2})[/.-](\d{1,2})[/.-](\d{2,4})$/);
  if (m) {
    const year = m[3].length === 2 ? `20${m[3]}` : m[3];
    return `${year}-${pad2(m[2])}-${pad2(m[1])}`;
  }
  m = v.match(/^(\d{1,2})[/.-](\d{4})$/);
  if (m) return `${m[2]}-${pad2(m[1])}-01`;
  return null;
}

function parseAmount(value) {
  let v = String(value ?? '').replace(/[\s\u00a0\u202f€"]/g, '');
  if (v === '') return null;
  if (v.includes(',') && v.includes('.')) {
    v = v.lastIndexOf(',') > v.lastIndexOf('.') ? v.replace(/\./g, '').replace(',', '.') : v.replace(/,/g, '');
  } else {
    v = v.replace(',', '.');
  }
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

function splitLine(line, sep) {
  const out = [];
  let cur = '';
  let quoted = false;
  for (const ch of line) {
    if (ch === '"') quoted = !quoted;
    else if (ch === sep && !quoted) {
      out.push(cur);
      cur = '';
    } else cur += ch;
  }
  out.push(cur);
  return out.map((s) => s.trim());
}

/**
 * Parses a bank amortization table exported as CSV (separator ; tab or ,).
 * Requires a header row with at least a date column and a capital or payment column.
 */
export function parseScheduleCsv(text, loanPrincipal = 0) {
  const lines = String(text || '')
    .replace(/^\uFEFF/, '')
    .split(/\r?\n/)
    .filter((l) => l.trim() !== '');
  if (lines.length < 2) throw new Error('Le fichier doit contenir une ligne d’en-tête et au moins une échéance.');

  const sep = [';', '\t', ','].find((s) => lines[0].includes(s)) || ';';
  const headers = splitLine(lines[0], sep);
  const mapping = {};
  headers.forEach((h, idx) => {
    const col = detectColumn(h);
    if (col && mapping[col] === undefined) mapping[col] = idx;
  });
  if (mapping.due_date === undefined) throw new Error('Colonne « date » introuvable dans l’en-tête.');
  if (mapping.principal === undefined && mapping.payment === undefined) {
    throw new Error('Colonne « capital » ou « mensualité » introuvable dans l’en-tête.');
  }

  const rows = [];
  for (const line of lines.slice(1)) {
    const cells = splitLine(line, sep);
    const due_date = parseDate(cells[mapping.due_date]);
    if (!due_date) continue;
    const get = (key) => (mapping[key] === undefined ? null : parseAmount(cells[mapping[key]]));
    const interest = get('interest') ?? 0;
    const insurance = get('insurance') ?? 0;
    let principal = get('principal');
    let payment = get('payment');
    if (principal === null) principal = (payment ?? 0) - interest - insurance;
    if (payment === null) payment = principal + interest + insurance;
    const rem = get('remaining');
    const number = mapping.number !== undefined ? Math.trunc(num(cells[mapping.number], rows.length + 1)) : rows.length + 1;
    rows.push({
      number,
      due_date,
      principal: round2(principal),
      interest: round2(interest),
      insurance: round2(insurance),
      payment: round2(payment),
      remaining: rem === null ? null : round2(rem),
    });
  }
  if (!rows.length) throw new Error('Aucune échéance valide trouvée (vérifiez le format des dates).');

  if (rows.some((r) => r.remaining === null)) {
    let remaining = num(loanPrincipal) > 0 ? num(loanPrincipal) : rows.reduce((s, r) => s + r.principal, 0);
    for (const r of rows) {
      remaining = round2(remaining - r.principal);
      if (r.remaining === null) r.remaining = Math.max(remaining, 0);
      else remaining = r.remaining;
    }
  }
  return rows;
}
