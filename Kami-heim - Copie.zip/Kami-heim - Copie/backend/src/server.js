import archiver from 'archiver';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import multer from 'multer';
import { DOCUMENT_CATEGORIES, EXPENSE_CATEGORIES, PAYMENT_METHODS } from './constants.js';
import { DATA_DIR, UPLOAD_DIR, db } from './db.js';
import dashboard from './routes/dashboard.js';
import documents from './routes/documents.js';
import expenses from './routes/expenses.js';
import loans from './routes/loans.js';
import properties from './routes/properties.js';
import regularizations from './routes/regularizations.js';
import rents from './routes/rents.js';
import settings from './routes/settings.js';
import tenants from './routes/tenants.js';
import { isoDate } from './util.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const PUBLIC_DIR = path.resolve(process.env.PUBLIC_DIR || path.join(__dirname, '../../frontend/dist'));

const app = express();
app.disable('x-powered-by');

// Optional HTTP basic auth, enabled when APP_PASSWORD is set (useful when exposed on a network).
if (process.env.APP_PASSWORD) {
  const expectedUser = process.env.APP_USER || 'admin';
  const expected = Buffer.from(`${expectedUser}:${process.env.APP_PASSWORD}`);
  app.use((req, res, next) => {
    const header = req.headers.authorization || '';
    const given = Buffer.from(header.startsWith('Basic ') ? Buffer.from(header.slice(6), 'base64').toString() : '');
    if (given.length === expected.length && crypto.timingSafeEqual(given, expected)) return next();
    res.setHeader('WWW-Authenticate', 'Basic realm="Kami-heim", charset="UTF-8"');
    res.status(401).send('Authentification requise');
  });
}

app.use(express.json({ limit: '10mb' }));

app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));
app.get('/api/meta', (_req, res) =>
  res.json({ expense_categories: EXPENSE_CATEGORIES, document_categories: DOCUMENT_CATEGORIES, payment_methods: PAYMENT_METHODS }),
);

app.use('/api/settings', settings);
app.use('/api/properties', properties);
app.use('/api/tenants', tenants);
app.use('/api/documents', documents);
app.use('/api/rents', rents);
app.use('/api/expenses', expenses);
app.use('/api/regularizations', regularizations);
app.use('/api/loans', loans);
app.use('/api/dashboard', dashboard);

/** Downloads a zip containing a consistent copy of the database and all uploaded documents. */
app.get('/api/backup', async (_req, res, next) => {
  const tmp = path.join(os.tmpdir(), `kamiheim-${crypto.randomUUID()}.db`);
  try {
    await db.backup(tmp);
  } catch (err) {
    return next(err);
  }
  const cleanup = () => fs.rm(tmp, { force: true }, () => {});
  res.attachment(`kami-heim-sauvegarde-${isoDate(new Date())}.zip`);
  const archive = archiver('zip', { zlib: { level: 9 } });
  archive.on('error', (err) => {
    cleanup();
    next(err);
  });
  res.on('close', cleanup);
  archive.pipe(res);
  archive.file(tmp, { name: 'kamiheim.db' });
  archive.directory(UPLOAD_DIR, 'uploads');
  archive.finalize();
});

app.use('/api', (_req, res) => res.status(404).json({ error: 'Route inconnue' }));

if (fs.existsSync(PUBLIC_DIR)) {
  app.use(express.static(PUBLIC_DIR, { index: false, maxAge: '1h' }));
  app.get('*', (_req, res) => res.sendFile(path.join(PUBLIC_DIR, 'index.html')));
}

// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  let status = err.status || 500;
  let message = err.message || 'Erreur interne';
  if (err instanceof multer.MulterError) {
    status = 400;
    message = err.code === 'LIMIT_FILE_SIZE' ? 'Fichier trop volumineux (50 Mo maximum)' : `Erreur d'envoi : ${err.message}`;
  } else if (typeof err.code === 'string' && err.code.startsWith('SQLITE_CONSTRAINT')) {
    if (err.code === 'SQLITE_CONSTRAINT_UNIQUE') {
      status = 409;
      message = 'Un enregistrement existe déjà pour cette période / ce locataire.';
    } else if (err.code === 'SQLITE_CONSTRAINT_FOREIGNKEY') {
      status = 400;
      message = 'Référence invalide (bien ou locataire inexistant).';
    } else {
      status = 400;
      message = 'Donnée obligatoire manquante ou invalide.';
    }
  } else if (err.type === 'entity.parse.failed') {
    status = 400;
    message = 'Requête JSON invalide';
  }
  if (status >= 500) console.error(err);
  res.status(status).json({ error: message });
});

app.listen(PORT, () => {
  console.log(`Kami-heim démarré sur http://localhost:${PORT} (données : ${DATA_DIR})`);
});
