import { Router } from 'express';
import { db } from './db.js';
import { httpError, num, str } from './util.js';

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const PERIOD_RE = /^\d{4}-\d{2}$/;

/**
 * Converts request body values according to a field schema.
 * Field types: text, number, int, date (YYYY-MM-DD), period (YYYY-MM).
 */
export function parseFields(schema, body, { partial = false } = {}) {
  const out = {};
  for (const [key, def] of Object.entries(schema)) {
    const label = def.label || key;
    if (!(key in body)) {
      if (!partial && def.required && def.default === undefined) throw httpError(400, `Champ requis : ${label}`);
      if (!partial && def.default !== undefined) out[key] = def.default;
      continue;
    }
    const raw = body[key];
    let value;
    switch (def.type) {
      case 'number':
      case 'int': {
        if (raw === null || raw === '' || raw === undefined) {
          value = def.default ?? null;
        } else {
          value = num(raw, NaN);
          if (Number.isNaN(value)) throw httpError(400, `Valeur numérique invalide : ${label}`);
          if (def.type === 'int') value = Math.trunc(value);
        }
        break;
      }
      case 'date':
        value = str(raw);
        if (value !== null && !DATE_RE.test(value)) throw httpError(400, `Date invalide (AAAA-MM-JJ) : ${label}`);
        break;
      case 'period':
        value = str(raw);
        if (value !== null && !PERIOD_RE.test(value)) throw httpError(400, `Période invalide (AAAA-MM) : ${label}`);
        break;
      default:
        value = str(raw);
    }
    if (def.required && value === null) throw httpError(400, `Champ requis : ${label}`);
    out[key] = value;
  }
  return out;
}

/**
 * Builds a REST router (list/get/create/update/delete) for a table.
 * filters: list of query params; either a column name or { param, sql } with a single "?" placeholder.
 */
export function crudRouter({
  table,
  fields,
  filters = [],
  select,
  alias,
  orderBy = 'id DESC',
  beforeSave,
  beforeDelete,
  afterSave,
}) {
  const router = Router();
  const a = alias ? `${alias}.` : '';
  const baseSelect = select || `SELECT * FROM ${table}`;
  const getOne = (id) => db.prepare(`${baseSelect} WHERE ${a}id = ?`).get(id);

  router.get('/', (req, res) => {
    const where = [];
    const params = [];
    for (const f of filters) {
      const param = typeof f === 'string' ? f : f.param;
      const sql = typeof f === 'string' ? `${a}${f} = ?` : f.sql;
      const value = req.query[param];
      if (value !== undefined && value !== '') {
        where.push(sql);
        params.push(value);
      }
    }
    const sql = `${baseSelect}${where.length ? ` WHERE ${where.join(' AND ')}` : ''} ORDER BY ${orderBy}`;
    res.json(db.prepare(sql).all(...params));
  });

  router.get('/:id', (req, res) => {
    const row = getOne(req.params.id);
    if (!row) throw httpError(404, 'Élément introuvable');
    res.json(row);
  });

  router.post('/', (req, res) => {
    let data = parseFields(fields, req.body || {});
    if (beforeSave) data = beforeSave(data, null) || data;
    const cols = Object.keys(data);
    const info = db
      .prepare(`INSERT INTO ${table} (${cols.join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`)
      .run(...cols.map((c) => data[c]));
    if (afterSave) afterSave(info.lastInsertRowid, data, true);
    res.status(201).json(getOne(info.lastInsertRowid));
  });

  router.put('/:id', (req, res) => {
    const existing = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(req.params.id);
    if (!existing) throw httpError(404, 'Élément introuvable');
    let data = parseFields(fields, req.body || {}, { partial: true });
    if (beforeSave) data = beforeSave(data, existing) || data;
    const cols = Object.keys(data);
    if (cols.length) {
      db.prepare(`UPDATE ${table} SET ${cols.map((c) => `${c} = ?`).join(', ')} WHERE id = ?`).run(
        ...cols.map((c) => data[c]),
        existing.id,
      );
    }
    if (afterSave) afterSave(existing.id, data, false);
    res.json(getOne(existing.id));
  });

  router.delete('/:id', (req, res) => {
    const existing = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(req.params.id);
    if (!existing) throw httpError(404, 'Élément introuvable');
    if (beforeDelete) beforeDelete(existing);
    db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(existing.id);
    res.status(204).end();
  });

  return router;
}
