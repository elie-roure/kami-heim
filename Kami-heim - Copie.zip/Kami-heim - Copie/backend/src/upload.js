import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import multer from 'multer';
import { UPLOAD_DIR } from './db.js';

const storage = multer.diskStorage({
  destination: UPLOAD_DIR,
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase().replace(/[^.a-z0-9]/g, '').slice(0, 10);
    cb(null, `${crypto.randomUUID()}${ext}`);
  },
});

export const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 } });

/** Busboy decodes multipart filenames as latin1; recover UTF-8 names (accents). */
export function fixFileName(name) {
  if (!name) return name;
  const decoded = Buffer.from(name, 'latin1').toString('utf8');
  return decoded.includes('\uFFFD') ? name : decoded;
}

export function uploadPath(filename) {
  const resolved = path.resolve(UPLOAD_DIR, path.basename(filename));
  return resolved;
}

export function removeUpload(filename) {
  if (!filename) return;
  fs.rm(uploadPath(filename), { force: true }, () => {});
}
