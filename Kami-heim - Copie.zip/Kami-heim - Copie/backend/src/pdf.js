import fs from 'node:fs';
import PDFDocument from 'pdfkit';
import { amountToWords, daysInMonth, formatEur, frDate, isoDate, monthLabel, pad2, round2 } from './util.js';

const M = 50;
const PAGE_W = 595.28;
const W = PAGE_W - 2 * M;
const PRIMARY = '#1f3a5f';
const BORDER = '#9aa9bd';

export function streamPdf(res, filename, build) {
  const doc = new PDFDocument({ size: 'A4', margin: M, info: { Title: filename, Producer: 'Kami-heim' } });
  const safe = filename.normalize('NFD').replace(/[^\w.-]+/g, '_');
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename="${safe}"`);
  doc.pipe(res);
  build(doc);
  doc.end();
}

function header(doc, title, subtitle) {
  doc.font('Helvetica-Bold').fontSize(20).fillColor(PRIMARY).text(title, M, M, { width: W, align: 'center' });
  if (subtitle) {
    doc.moveDown(0.3).font('Helvetica').fontSize(12).fillColor('#333').text(subtitle, M, doc.y, { width: W, align: 'center' });
  }
  doc.moveDown(1.5);
}

function partyBoxes(doc, left, right) {
  const top = doc.y;
  const colW = (W - 20) / 2;
  const draw = (box, x) => {
    doc.font('Helvetica-Bold').fontSize(9).fillColor(PRIMARY).text(box.title.toUpperCase(), x + 10, top + 10, { width: colW - 20 });
    doc.moveDown(0.3).font('Helvetica').fontSize(11).fillColor('#000');
    box.lines.filter(Boolean).forEach((l) => doc.text(l, x + 10, doc.y, { width: colW - 20 }));
    return doc.y;
  };
  const b1 = draw(left, M);
  const b2 = draw(right, M + colW + 20);
  const bottom = Math.max(b1, b2) + 10;
  doc.lineWidth(0.8).strokeColor(BORDER);
  doc.roundedRect(M, top, colW, bottom - top, 4).stroke();
  doc.roundedRect(M + colW + 20, top, colW, bottom - top, 4).stroke();
  doc.x = M;
  doc.y = bottom + 15;
}

function paragraph(doc, text, opts = {}) {
  doc.font(opts.bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(opts.size || 11).fillColor('#000')
    .text(text, M, doc.y, { width: W, align: opts.align || 'justify', lineGap: 2 });
  doc.moveDown(opts.after ?? 1);
}

/** columns: [{ header, width (ratio), align }], rows: [{ cells: [], bold }] */
function table(doc, columns, rows) {
  const rowH = 22;
  let y = doc.y;
  const top = y;
  const xs = [];
  let x = M;
  for (const c of columns) {
    xs.push(x);
    x += c.width * W;
  }
  const drawRow = (cells, { bold = false, fill = null } = {}) => {
    if (fill) doc.rect(M, y, W, rowH).fill(fill);
    doc.fillColor('#000').font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(10.5);
    cells.forEach((cell, i) => {
      doc.text(String(cell ?? ''), xs[i] + 8, y + 6, { width: columns[i].width * W - 16, align: columns[i].align || 'left', lineBreak: false, ellipsis: true });
    });
    y += rowH;
    doc.moveTo(M, y).lineTo(M + W, y).lineWidth(0.5).strokeColor('#d0d7e2').stroke();
  };
  if (columns.some((c) => c.header)) drawRow(columns.map((c) => c.header), { bold: true, fill: '#dfe6f0' });
  rows.forEach((r) => drawRow(r.cells, { bold: r.bold, fill: r.bold ? '#eef2f7' : null }));
  doc.rect(M, top, W, y - top).lineWidth(0.8).strokeColor(BORDER).stroke();
  doc.x = M;
  doc.y = y + 15;
}

function signature(doc, settings, signaturePath, dateIso) {
  doc.font('Helvetica').fontSize(11).fillColor('#000');
  doc.text(`Fait à ${settings.owner_city || '................'}, le ${frDate(dateIso)}`, M, doc.y, { width: W, align: 'right' });
  doc.moveDown(0.3);
  doc.text('Le bailleur', M, doc.y, { width: W, align: 'right' });
  if (signaturePath && fs.existsSync(signaturePath)) {
    try {
      doc.image(signaturePath, M + W - 170, doc.y + 5, { fit: [170, 70], align: 'right' });
    } catch {
      // ignore unreadable signature image
    }
  }
  doc.y += 80;
}

function footer(doc, text) {
  doc.font('Helvetica').fontSize(8).fillColor('#555').text(text, M, 745, { width: W, align: 'center' });
}

const personName = (t) => [t.first_name, t.last_name].filter(Boolean).join(' ');
const addressLines = (p) => [p.address, [p.postal_code, p.city].filter(Boolean).join(' ')].filter(Boolean);

function ownerBox(settings) {
  return {
    title: 'Bailleur',
    lines: [
      settings.owner_name || 'Nom du bailleur (à renseigner dans Paramètres)',
      settings.owner_address,
      [settings.owner_postal_code, settings.owner_city].filter(Boolean).join(' '),
      settings.owner_email,
      settings.owner_phone,
    ],
  };
}

export function buildReceipt(doc, { settings, tenant, property, payment, signaturePath }) {
  const [y, m] = payment.period.split('-').map(Number);
  const start = `01/${pad2(m)}/${y}`;
  const end = `${daysInMonth(y, m)}/${pad2(m)}/${y}`;
  const total = round2(payment.rent_amount + payment.charges_amount);
  const paid = round2(payment.paid_amount);
  const full = paid >= total - 0.005;
  const owner = settings.owner_name || 'le bailleur';
  const tenantName = personName(tenant);

  header(doc, full ? 'QUITTANCE DE LOYER' : 'REÇU DE PAIEMENT PARTIEL', `Période : ${monthLabel(payment.period)}`);
  partyBoxes(doc, ownerBox(settings), { title: 'Locataire', lines: [tenantName, ...addressLines(property)] });

  paragraph(doc, `Adresse du logement loué : ${[property.name, ...addressLines(property)].join(', ')}`, { bold: true });

  if (full) {
    paragraph(
      doc,
      `Je soussigné(e) ${owner}, bailleur du logement désigné ci-dessus, déclare avoir reçu de ${tenantName} ` +
        `la somme de ${formatEur(paid)} (${amountToWords(paid)}), au titre du paiement du loyer et des charges ` +
        `pour la période de location du ${start} au ${end}, et lui en donne quittance, sous réserve de tous mes droits.`,
    );
  } else {
    paragraph(
      doc,
      `Je soussigné(e) ${owner}, bailleur du logement désigné ci-dessus, déclare avoir reçu de ${tenantName} ` +
        `la somme de ${formatEur(paid)} (${amountToWords(paid)}), à titre d'acompte sur le loyer et les charges ` +
        `de la période du ${start} au ${end}. Ce reçu ne vaut pas quittance.`,
    );
  }

  const rows = [
    { cells: ['Loyer hors charges', formatEur(payment.rent_amount)] },
    { cells: ['Provision pour charges', formatEur(payment.charges_amount)] },
    { cells: ['Total du terme', formatEur(total)], bold: true },
    { cells: ['Montant reçu', formatEur(paid)] },
  ];
  if (!full) rows.push({ cells: ['Reste dû', formatEur(total - paid)], bold: true });
  table(doc, [{ header: 'Détail', width: 0.6 }, { header: 'Montant', width: 0.4, align: 'right' }], rows);

  const info = [];
  if (payment.payment_date) info.push(`Date du paiement : ${frDate(payment.payment_date)}`);
  if (payment.method) info.push(`Mode de paiement : ${payment.method}`);
  if (info.length) paragraph(doc, info.join('     '), { align: 'left' });

  doc.moveDown(1);
  signature(doc, settings, signaturePath, payment.payment_date || isoDate(new Date()));

  footer(
    doc,
    full
      ? 'Cette quittance annule tous les reçus qui auraient pu être établis précédemment en cas de paiement partiel du montant du présent terme. ' +
          'Elle est délivrée en application de l’article 21 de la loi n° 89-462 du 6 juillet 1989.'
      : 'Le présent reçu ne libère pas le locataire du solde restant dû pour cette période.',
  );
}

export function buildRegularization(doc, { settings, tenant, property, reg, signaturePath }) {
  const details = typeof reg.details === 'string' ? JSON.parse(reg.details || '{}') : reg.details || {};
  const lines = details.lines || [];
  const tenantName = personName(tenant);

  header(doc, 'RÉGULARISATION DES CHARGES', `Année ${reg.year} — période du ${frDate(reg.period_start)} au ${frDate(reg.period_end)}`);
  partyBoxes(doc, ownerBox(settings), { title: 'Locataire', lines: [tenantName, ...addressLines(property)] });

  paragraph(
    doc,
    `Conformément à l'article 23 de la loi n° 89-462 du 6 juillet 1989, veuillez trouver ci-dessous le décompte ` +
      `des charges récupérables pour le logement${property.name ? ` « ${property.name} »` : ''}` +
      `${addressLines(property).length ? ` situé ${addressLines(property).join(', ')}` : ''}.`,
  );

  if (details.occupancy_days && details.year_days && details.occupancy_days < details.year_days) {
    const pct = ((details.occupancy_days / details.year_days) * 100).toFixed(1).replace('.', ',');
    paragraph(doc, `Prorata d'occupation : ${details.occupancy_days} jours sur ${details.year_days} (${pct} %).`, { after: 0.6 });
  }

  table(
    doc,
    [
      { header: 'Nature de la charge', width: 0.5 },
      { header: 'Montant annuel', width: 0.25, align: 'right' },
      { header: 'Quote-part locataire', width: 0.25, align: 'right' },
    ],
    [
      ...lines.map((l) => ({ cells: [l.label, formatEur(l.total), formatEur(l.share)] })),
      { cells: ['Total des charges réelles', '', formatEur(reg.actual_charges)], bold: true },
    ],
  );

  const balance = round2(reg.balance);
  table(doc, [{ width: 0.6 }, { width: 0.4, align: 'right' }], [
    { cells: ['Charges réelles dues', formatEur(reg.actual_charges)] },
    { cells: ['Provisions pour charges versées', formatEur(reg.provisions)] },
    {
      cells: [balance >= 0 ? 'Solde restant dû par le locataire' : 'Trop-perçu à rembourser au locataire', formatEur(Math.abs(balance))],
      bold: true,
    },
  ]);

  if (balance > 0) {
    paragraph(doc, `Vous restez redevable de la somme de ${formatEur(balance)} (${amountToWords(balance)}).`);
  } else if (balance < 0) {
    paragraph(doc, `La somme de ${formatEur(-balance)} (${amountToWords(-balance)}) vous sera remboursée ou déduite de votre prochain loyer.`);
  } else {
    paragraph(doc, 'Les provisions versées couvrent exactement les charges réelles : aucun solde n’est dû.');
  }
  if (reg.new_provision) {
    paragraph(doc, `À compter du prochain terme, la provision mensuelle pour charges est fixée à ${formatEur(reg.new_provision)}.`);
  }
  if (reg.notes) paragraph(doc, reg.notes);

  signature(doc, settings, signaturePath, isoDate(new Date()));
  footer(doc, 'Les pièces justificatives sont tenues à la disposition du locataire pendant six mois à compter de l’envoi du présent décompte.');
}
