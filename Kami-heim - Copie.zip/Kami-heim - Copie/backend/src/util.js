export function httpError(status, message) {
  const err = new Error(message);
  err.status = status;
  return err;
}

export function num(value, fallback = 0) {
  if (value === null || value === undefined || value === '') return fallback;
  if (typeof value === 'number') return Number.isFinite(value) ? value : fallback;
  const cleaned = String(value).replace(/[\s\u00a0\u202f€]/g, '').replace(',', '.');
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : fallback;
}

export function str(value) {
  if (value === null || value === undefined) return null;
  const s = String(value).trim();
  return s === '' ? null : s;
}

export const round2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;

export const pad2 = (n) => String(n).padStart(2, '0');

export function isoDate(d) {
  return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
}

export function daysInMonth(year, month) {
  return new Date(year, month, 0).getDate();
}

/** Adds months to an ISO date, clamping the day to the end of the target month. */
export function addMonths(iso, months) {
  const [y, m, d] = iso.split('-').map(Number);
  const total = y * 12 + (m - 1) + months;
  const ny = Math.floor(total / 12);
  const nm = (total % 12) + 1;
  return `${ny}-${pad2(nm)}-${pad2(Math.min(d, daysInMonth(ny, nm)))}`;
}

function isoToUtc(iso) {
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
  return Date.UTC(y, m - 1, d);
}

export function daysBetween(startIso, endIso) {
  return Math.round((isoToUtc(endIso) - isoToUtc(startIso)) / 86400000);
}

export function frDate(iso) {
  if (!iso) return '';
  const [y, m, d] = iso.slice(0, 10).split('-');
  return `${d}/${m}/${y}`;
}

export function formatEur(value) {
  return new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' })
    .format(Number(value) || 0)
    .replace(/[\u202f\u00a0]/g, ' ');
}

const UNITS = [
  'zéro', 'un', 'deux', 'trois', 'quatre', 'cinq', 'six', 'sept', 'huit', 'neuf', 'dix',
  'onze', 'douze', 'treize', 'quatorze', 'quinze', 'seize', 'dix-sept', 'dix-huit', 'dix-neuf',
];
const TENS = ['', '', 'vingt', 'trente', 'quarante', 'cinquante', 'soixante'];

function below100(n) {
  if (n < 20) return UNITS[n];
  const t = Math.floor(n / 10);
  const u = n % 10;
  if (t === 7) return u === 1 ? 'soixante et onze' : `soixante-${UNITS[10 + u]}`;
  if (t === 8) return u === 0 ? 'quatre-vingts' : `quatre-vingt-${UNITS[u]}`;
  if (t === 9) return `quatre-vingt-${UNITS[10 + u]}`;
  if (u === 0) return TENS[t];
  if (u === 1) return `${TENS[t]} et un`;
  return `${TENS[t]}-${UNITS[u]}`;
}

function below1000(n) {
  const h = Math.floor(n / 100);
  const r = n % 100;
  const parts = [];
  if (h === 1) parts.push('cent');
  else if (h > 1) parts.push(`${UNITS[h]} cent${r === 0 ? 's' : ''}`);
  if (r > 0) parts.push(below100(r));
  return parts.join(' ');
}

export function numberToWords(n) {
  n = Math.floor(Math.abs(n));
  if (n === 0) return 'zéro';
  const parts = [];
  const millions = Math.floor(n / 1_000_000);
  const thousands = Math.floor((n % 1_000_000) / 1000);
  const rest = n % 1000;
  if (millions) parts.push(millions === 1 ? 'un million' : `${below1000(millions)} millions`);
  if (thousands) {
    parts.push(thousands === 1 ? 'mille' : `${below1000(thousands).replace(/(cent|vingt)s$/, '$1')} mille`);
  }
  if (rest) parts.push(below1000(rest));
  return parts.join(' ');
}

export function amountToWords(amount) {
  const cents = Math.round(Math.abs(Number(amount) || 0) * 100);
  const euros = Math.floor(cents / 100);
  const c = cents % 100;
  let text = `${numberToWords(euros)} euro${euros > 1 ? 's' : ''}`;
  if (c) text += ` et ${numberToWords(c)} centime${c > 1 ? 's' : ''}`;
  return text;
}

export function monthLabel(period) {
  const [y, m] = period.split('-').map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
}
