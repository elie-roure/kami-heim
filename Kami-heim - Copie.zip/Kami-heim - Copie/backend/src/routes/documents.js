import { Router } from 'express';
import fs from 'node:fs';
import { parseFields } from '../crud.js';
import { db } from '../db.js';
import { httpError } from '../util.js';
import { fixFileName, removeUpload, upload, uploadPath } from '../upload.js';

const router = Router();

const fields = {
  property_id: { type: 'int' },
  tenant_id: { type: 'int' },
  category: { type: 'text', default: 'autre' },
  title: { type: 'text' },
  document_date: { type: 'date', label: 'Date du document' },
  notes: { type: 'text' },
};

const SELECT = `SELECT d.*, t.first_name AS tenant_first_name, t.last_name AS tenant_last_name
  FROM documents d LEFT JOIN tenants t ON t.id = d.tenant_id`;

const getOne = (id) => db.prepare(`${SELECT} WHERE d.id = ?`).get(id);

router.get('/', (req, res) => {
  const where = [];
  const params = [];
  for (const [param, sql] of [
    ['property_id', 'd.property_id = ?'],
    ['tenant_id', 'd.tenant_id = ?'],
    ['category', 'd.category = ?'],
  ]) {
    if (req.query[param]) {
      where.push(sql);
      params.push(req.query[param]);
    }
  }
  const sql = `${SELECT}${where.length ? ` WHERE ${where.join(' AND ')}` : ''}
    ORDER BY COALESCE(d.document_date, d.uploaded_at) DESC, d.id DESC`;
  res.json(db.prepare(sql).all(...params));
});

function resolveOwnership(data) {
  if (data.tenant_id) {
    const tenant = db.prepare('SELECT id, property_id FROM tenants WHERE id = ?').get(data.tenant_id);
    if (!tenant) throw httpError(400, 'Locataire introuvable');
    data.property_id = tenant.property_id;
  }
  return data;
}

router.post('/', upload.single('file'), (req, res) => {
  if (!req.file) throw httpError(400, 'Aucun fichier reçu');
  try {
    const data = resolveOwnership(parseFields(fields, req.body || {}));
    if (!data.property_id) throw httpError(400, 'Champ requis : Bien');
    const originalName = fixFileName(req.file.originalname);
    const info = db
      .prepare(
        `INSERT INTO documents (property_id, tenant_id, category, title, filename, original_name, mime_type, size, document_date, notes)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .run(
        data.property_id,
        data.tenant_id ?? null,
        data.category || 'autre',
        data.title || originalName,
        req.file.filename,
        originalName,
        req.file.mimetype,
        req.file.size,
        data.document_date ?? null,
        data.notes ?? null,
      );
    res.status(201).json(getOne(info.lastInsertRowid));
  } catch (err) {
    removeUpload(req.file.filename);
    throw err;
  }
});

router.put('/:id', (req, res) => {
  const doc = db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id);
  if (!doc) throw httpError(404, 'Document introuvable');
  const data = resolveOwnership(parseFields(fields, req.body || {}, { partial: true }));
  const cols = Object.keys(data).filter((c) => !(c === 'title' && !data.title));
  if (cols.length) {
    db.prepare(`UPDATE documents SET ${cols.map((c) => `${c} = ?`).join(', ')} WHERE id = ?`).run(...cols.map((c) => data[c]), doc.id);
  }
  res.json(getOne(doc.id));
});

router.get('/:id/file', (req, res) => {
  const doc = db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id);
  if (!doc) throw httpError(404, 'Document introuvable');
  const file = uploadPath(doc.filename);
  if (!fs.existsSync(file)) throw httpError(404, 'Fichier manquant sur le disque');
  const name = doc.original_name || doc.filename;
  if (req.query.download) return res.download(file, name);
  res.setHeader('Content-Disposition', `inline; filename*=UTF-8''${encodeURIComponent(name)}`);
  if (doc.mime_type) res.type(doc.mime_type);
  res.sendFile(file);
});

router.delete('/:id', (req, res) => {
  const doc = db.prepare('SELECT * FROM documents WHERE id = ?').get(req.params.id);
  if (!doc) throw httpError(404, 'Document introuvable');
  db.prepare('DELETE FROM documents WHERE id = ?').run(doc.id);
  removeUpload(doc.filename);
  res.status(204).end();
});

export default router;
