import { Router } from 'express';
import fs from 'node:fs';
import { db, getSettings } from '../db.js';
import { httpError } from '../util.js';
import { removeUpload, upload, uploadPath } from '../upload.js';

const router = Router();

const KEYS = ['owner_name', 'owner_address', 'owner_postal_code', 'owner_city', 'owner_email', 'owner_phone'];

function publicSettings() {
  const s = getSettings();
  const out = Object.fromEntries(KEYS.map((k) => [k, s[k] ?? '']));
  out.has_signature = Boolean(s.signature_file);
  return out;
}

function setSetting(key, value) {
  db.prepare('INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(key, value);
}

router.get('/', (_req, res) => res.json(publicSettings()));

router.put('/', (req, res) => {
  const body = req.body || {};
  db.transaction(() => {
    for (const k of KEYS) if (k in body) setSetting(k, String(body[k] ?? '').trim());
  })();
  res.json(publicSettings());
});

router.post('/signature', upload.single('file'), (req, res) => {
  if (!req.file) throw httpError(400, 'Aucun fichier reçu');
  if (!/^image\/(png|jpe?g)$/.test(req.file.mimetype)) {
    removeUpload(req.file.filename);
    throw httpError(400, 'La signature doit être une image PNG ou JPEG');
  }
  const previous = getSettings().signature_file;
  setSetting('signature_file', req.file.filename);
  if (previous) removeUpload(previous);
  res.json(publicSettings());
});

router.get('/signature', (_req, res) => {
  const file = getSettings().signature_file;
  if (!file || !fs.existsSync(uploadPath(file))) throw httpError(404, 'Aucune signature');
  res.sendFile(uploadPath(file));
});

router.delete('/signature', (_req, res) => {
  const file = getSettings().signature_file;
  if (file) removeUpload(file);
  db.prepare("DELETE FROM settings WHERE key = 'signature_file'").run();
  res.json(publicSettings());
});

export function signaturePath() {
  const file = getSettings().signature_file;
  return file ? uploadPath(file) : null;
}

export default router;
