import { crudRouter } from '../crud.js';
import { db } from '../db.js';
import { removeUpload } from '../upload.js';

export const propertyFields = {
  name: { type: 'text', required: true, label: 'Nom du bien' },
  address: { type: 'text' },
  postal_code: { type: 'text' },
  city: { type: 'text' },
  type: { type: 'text' },
  surface: { type: 'number' },
  rooms: { type: 'int' },
  purchase_price: { type: 'number' },
  notary_fees: { type: 'number' },
  purchase_date: { type: 'date' },
  notes: { type: 'text' },
};

export default crudRouter({
  table: 'properties',
  fields: propertyFields,
  orderBy: 'name COLLATE NOCASE',
  beforeDelete: (property) => {
    const files = db.prepare('SELECT filename FROM documents WHERE property_id = ?').all(property.id);
    files.forEach((f) => removeUpload(f.filename));
  },
});
