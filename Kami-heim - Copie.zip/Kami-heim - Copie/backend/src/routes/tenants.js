import { crudRouter } from '../crud.js';
import { db } from '../db.js';
import { removeUpload } from '../upload.js';

export default crudRouter({
  table: 'tenants',
  fields: {
    property_id: { type: 'int', required: true, label: 'Bien' },
    first_name: { type: 'text' },
    last_name: { type: 'text', required: true, label: 'Nom' },
    email: { type: 'text' },
    phone: { type: 'text' },
    lease_start: { type: 'date', label: 'Début du bail' },
    lease_end: { type: 'date', label: 'Fin du bail' },
    rent_amount: { type: 'number', default: 0, label: 'Loyer hors charges' },
    charges_amount: { type: 'number', default: 0, label: 'Provision pour charges' },
    deposit: { type: 'number', default: 0 },
    payment_day: { type: 'int', default: 1 },
    notes: { type: 'text' },
  },
  filters: ['property_id'],
  orderBy: "COALESCE(lease_end, '9999-12-31') DESC, lease_start DESC",
  beforeDelete: (tenant) => {
    const files = db.prepare('SELECT filename FROM documents WHERE tenant_id = ?').all(tenant.id);
    files.forEach((f) => removeUpload(f.filename));
  },
});
