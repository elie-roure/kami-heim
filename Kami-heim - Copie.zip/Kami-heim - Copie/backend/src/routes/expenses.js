import { crudRouter, parseFields } from '../crud.js';
import { db } from '../db.js';
import { addMonths, httpError } from '../util.js';

const fields = {
  property_id: { type: 'int', required: true, label: 'Bien' },
  date: { type: 'date', required: true, label: 'Date' },
  category: { type: 'text', default: 'autre' },
  label: { type: 'text' },
  amount: { type: 'number', required: true, label: 'Montant' },
  recoverable_amount: { type: 'number', default: 0, label: 'Part récupérable' },
  notes: { type: 'text' },
};

const router = crudRouter({
  table: 'expenses',
  fields,
  filters: [
    'property_id',
    'category',
    { param: 'year', sql: 'substr(date, 1, 4) = ?' },
  ],
  orderBy: 'date DESC, id DESC',
});

/** Creates the same expense several times at a fixed interval (e.g. quarterly syndic calls). */
router.post('/recurring', (req, res) => {
  const body = req.body || {};
  const data = parseFields(fields, body);
  const count = Math.trunc(Number(body.count) || 0);
  const interval = Math.trunc(Number(body.interval_months) || 0);
  if (count < 1 || count > 120) throw httpError(400, 'Nombre d’occurrences invalide (1 à 120)');
  if (interval < 1 || interval > 24) throw httpError(400, 'Intervalle invalide (1 à 24 mois)');
  const insert = db.prepare(
    `INSERT INTO expenses (property_id, date, category, label, amount, recoverable_amount, notes)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
  );
  db.transaction(() => {
    for (let i = 0; i < count; i++) {
      insert.run(data.property_id, addMonths(data.date, i * interval), data.category, data.label, data.amount, data.recoverable_amount ?? 0, data.notes);
    }
  })();
  res.status(201).json({ created: count });
});

export default router;
