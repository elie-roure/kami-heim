import { Router } from 'express';
import { categoryLabel } from '../constants.js';
import { db } from '../db.js';
import { daysInMonth, isoDate, pad2, round2 } from '../util.js';

const router = Router();

router.get('/', (req, res) => {
  const now = new Date();
  const today = isoDate(now);
  const currentYear = now.getFullYear();
  const year = Math.trunc(Number(req.query.year)) || currentYear;
  const Y = String(year);
  const pid = req.query.property_id ? Number(req.query.property_id) : null;
  const pf = (col) => (pid ? ` AND ${col} = ?` : '');
  const pp = pid ? [pid] : [];

  const months = Array.from({ length: 12 }, (_, i) => ({
    month: i + 1,
    rent: 0,
    charges: 0,
    expenses: 0,
    interest: 0,
    insurance: 0,
    principal: 0,
  }));

  // Revenues (split proportionally between rent and charges)
  const payments = db
    .prepare(`SELECT id, tenant_id, period, rent_amount, charges_amount, paid_amount FROM rent_payments WHERE substr(period, 1, 4) = ?${pf('property_id')}`)
    .all(Y, ...pp);
  for (const p of payments) {
    const m = months[Number(p.period.slice(5, 7)) - 1];
    const due = p.rent_amount + p.charges_amount;
    const rentPart = due > 0 ? p.paid_amount * (p.rent_amount / due) : p.paid_amount;
    m.rent += rentPart;
    m.charges += p.paid_amount - rentPart;
  }

  // Totals of the current year stop at the current month; the monthly series still shows the whole year.
  const upto = year === currentYear ? now.getMonth() + 1 : 12;

  // Owner expenses
  const byCategory = {};
  let recoverable = 0;
  const expenses = db
    .prepare(`SELECT date, category, amount, recoverable_amount FROM expenses WHERE substr(date, 1, 4) = ?${pf('property_id')}`)
    .all(Y, ...pp);
  for (const e of expenses) {
    const idx = Number(e.date.slice(5, 7)) - 1;
    months[idx].expenses += e.amount;
    if (idx >= upto) continue;
    byCategory[e.category] = (byCategory[e.category] || 0) + e.amount;
    recoverable += e.recoverable_amount;
  }

  // Loan installments
  const installments = db
    .prepare(
      `SELECT i.due_date, i.principal, i.interest, i.insurance FROM loan_installments i JOIN loans l ON l.id = i.loan_id
       WHERE substr(i.due_date, 1, 4) = ?${pf('l.property_id')}`,
    )
    .all(Y, ...pp);
  for (const i of installments) {
    const m = months[Number(i.due_date.slice(5, 7)) - 1];
    m.interest += i.interest;
    m.insurance += i.insurance;
    m.principal += i.principal;
  }

  for (const m of months) for (const k of Object.keys(m)) if (k !== 'month') m[k] = round2(m[k]);
  const sum = (k) => round2(months.slice(0, upto).reduce((s, m) => s + m[k], 0));

  const totals = {
    rent: sum('rent'),
    charges: sum('charges'),
    expenses: sum('expenses'),
    recoverable: round2(recoverable),
    interest: sum('interest'),
    insurance: sum('insurance'),
    principal: sum('principal'),
  };
  totals.revenue = round2(totals.rent + totals.charges);
  totals.loan = round2(totals.interest + totals.insurance + totals.principal);
  totals.cashflow = round2(totals.revenue - totals.expenses - totals.loan);
  totals.result = round2(totals.revenue - totals.expenses - totals.interest - totals.insurance);

  // Investment & yield
  const props = db.prepare(`SELECT * FROM properties WHERE 1 = 1${pf('id')}`).all(...pp);
  const purchaseCost = round2(props.reduce((s, p) => s + (p.purchase_price || 0) + (p.notary_fees || 0), 0));
  const active = db
    .prepare(
      `SELECT COALESCE(SUM(rent_amount), 0) AS rent, COALESCE(SUM(charges_amount), 0) AS charges, COUNT(*) AS count FROM tenants
       WHERE (lease_start IS NULL OR lease_start <= ?) AND (lease_end IS NULL OR lease_end >= ?)${pf('property_id')}`,
    )
    .get(today, today, ...pp);
  const expectedAnnualRent = round2(active.rent * 12);

  const remainingDate = year < currentYear ? `${year}-12-31` : today;
  const loanRows = db
    .prepare(
      `SELECT l.principal, (SELECT remaining FROM loan_installments i WHERE i.loan_id = l.id AND i.due_date <= ?
         ORDER BY i.due_date DESC, i.number DESC LIMIT 1) AS remaining
       FROM loans l WHERE 1 = 1${pf('l.property_id')}`,
    )
    .all(remainingDate, ...pp);
  const loanRemaining = round2(loanRows.reduce((s, l) => s + (l.remaining ?? l.principal), 0));

  // Unpaid or partially paid rents
  const lastMonth = year < currentYear ? 12 : year === currentYear ? now.getMonth() + 1 : 0;
  const paidMap = new Map(payments.map((p) => [`${p.tenant_id}|${p.period}`, p]));
  const tenants = db
    .prepare(`SELECT t.*, p.name AS property_name FROM tenants t JOIN properties p ON p.id = t.property_id WHERE 1 = 1${pf('t.property_id')}`)
    .all(...pp);
  const unpaid = [];
  for (const t of tenants) {
    for (let m = 1; m <= lastMonth; m++) {
      const period = `${year}-${pad2(m)}`;
      const monthStart = `${period}-01`;
      const monthEnd = `${period}-${pad2(daysInMonth(year, m))}`;
      if (t.lease_start && t.lease_start > monthEnd) continue;
      if (t.lease_end && t.lease_end < monthStart) continue;
      const p = paidMap.get(`${t.id}|${period}`);
      const expected = round2(p ? p.rent_amount + p.charges_amount : t.rent_amount + t.charges_amount);
      const paid = round2(p ? p.paid_amount : 0);
      if (expected - paid > 0.01) {
        unpaid.push({
          tenant_id: t.id,
          tenant_name: [t.first_name, t.last_name].filter(Boolean).join(' '),
          property_name: t.property_name,
          period,
          expected,
          paid,
          missing: round2(expected - paid),
          payment_id: p?.id ?? null,
        });
      }
    }
  }

  // Multi-year history (up to the end of the current month)
  const cutoff = `${currentYear}-${pad2(now.getMonth() + 1)}-31`;
  const group = (sql) => db.prepare(sql).all(cutoff, ...pp);
  const rentYears = group(`SELECT substr(period, 1, 4) AS y, SUM(paid_amount) AS total FROM rent_payments WHERE period || '-01' <= ?${pf('property_id')} GROUP BY y`);
  const expYears = group(`SELECT substr(date, 1, 4) AS y, SUM(amount) AS total FROM expenses WHERE date <= ?${pf('property_id')} GROUP BY y`);
  const loanYears = group(
    `SELECT substr(i.due_date, 1, 4) AS y, SUM(i.interest + i.insurance) AS cost, SUM(i.principal) AS principal
     FROM loan_installments i JOIN loans l ON l.id = i.loan_id WHERE i.due_date <= ?${pf('l.property_id')} GROUP BY y`,
  );
  const years = new Set([String(currentYear), ...rentYears.map((r) => r.y), ...expYears.map((r) => r.y)]);
  loanYears.filter((l) => Number(l.y) <= currentYear).forEach((l) => years.add(l.y));
  const find = (arr, y) => arr.find((r) => r.y === y) || {};
  const history = [...years]
    .sort()
    .map((y) => {
      const revenue = round2(find(rentYears, y).total || 0);
      const exp = round2(find(expYears, y).total || 0);
      const loanCost = round2(find(loanYears, y).cost || 0);
      const principal = round2(find(loanYears, y).principal || 0);
      return { year: Number(y), revenue, expenses: exp, loan_cost: loanCost, principal, cashflow: round2(revenue - exp - loanCost - principal) };
    });

  res.json({
    year,
    property_id: pid,
    months_counted: upto,
    months,
    totals,
    by_category: Object.entries(byCategory)
      .map(([category, amount]) => ({ category, label: categoryLabel(category), amount: round2(amount) }))
      .sort((a, b) => b.amount - a.amount),
    purchase_cost: purchaseCost,
    expected_annual_rent: expectedAnnualRent,
    active_tenants: active.count,
    gross_yield: purchaseCost > 0 ? round2((expectedAnnualRent / purchaseCost) * 100) : null,
    net_yield: purchaseCost > 0 ? round2(((totals.revenue - totals.expenses - totals.interest - totals.insurance) / purchaseCost) * 100) : null,
    loan_remaining: loanRemaining,
    unpaid,
    history,
  });
});

export default router;
