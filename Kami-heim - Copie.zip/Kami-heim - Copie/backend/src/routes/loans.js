import { crudRouter } from '../crud.js';
import { db } from '../db.js';
import { computeSchedule, parseScheduleCsv } from '../loan.js';
import { httpError } from '../util.js';

const insertInstallment = db.prepare(
  `INSERT INTO loan_installments (loan_id, number, due_date, payment, principal, interest, insurance, remaining)
   VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
);

const replaceSchedule = db.transaction((loanId, rows) => {
  db.prepare('DELETE FROM loan_installments WHERE loan_id = ?').run(loanId);
  for (const r of rows) {
    insertInstallment.run(loanId, r.number, r.due_date, r.payment, r.principal, r.interest, r.insurance, r.remaining);
  }
});

const router = crudRouter({
  table: 'loans',
  alias: 'l',
  select: `SELECT l.*, p.name AS property_name,
      (SELECT COUNT(*) FROM loan_installments i WHERE i.loan_id = l.id) AS installments_count,
      (SELECT COALESCE(SUM(interest), 0) FROM loan_installments i WHERE i.loan_id = l.id) AS total_interest,
      (SELECT COALESCE(SUM(insurance), 0) FROM loan_installments i WHERE i.loan_id = l.id) AS total_insurance,
      (SELECT MAX(due_date) FROM loan_installments i WHERE i.loan_id = l.id) AS end_date,
      (SELECT payment FROM loan_installments i WHERE i.loan_id = l.id ORDER BY i.due_date LIMIT 1) AS monthly_payment,
      (SELECT remaining FROM loan_installments i WHERE i.loan_id = l.id AND i.due_date <= date('now')
         ORDER BY i.due_date DESC, i.number DESC LIMIT 1) AS remaining_today
    FROM loans l JOIN properties p ON p.id = l.property_id`,
  fields: {
    property_id: { type: 'int', required: true, label: 'Bien' },
    name: { type: 'text', required: true, label: 'Nom du prêt' },
    bank: { type: 'text' },
    principal: { type: 'number', required: true, label: 'Capital emprunté' },
    annual_rate: { type: 'number', default: 0, label: 'Taux annuel' },
    duration_months: { type: 'int', default: 0, label: 'Durée (mois)' },
    start_date: { type: 'date', required: true, label: 'Date de 1re échéance' },
    insurance_monthly: { type: 'number', default: 0, label: 'Assurance mensuelle' },
    notes: { type: 'text' },
  },
  filters: [{ param: 'property_id', sql: 'l.property_id = ?' }],
  orderBy: 'l.start_date',
  afterSave: (id, _data, created) => {
    if (!created) return;
    const loan = db.prepare('SELECT * FROM loans WHERE id = ?').get(id);
    replaceSchedule(id, computeSchedule(loan));
  },
});

function getLoan(id) {
  const loan = db.prepare('SELECT * FROM loans WHERE id = ?').get(id);
  if (!loan) throw httpError(404, 'Prêt introuvable');
  return loan;
}

router.get('/:id/installments', (req, res) => {
  getLoan(req.params.id);
  res.json(db.prepare('SELECT * FROM loan_installments WHERE loan_id = ? ORDER BY due_date, number').all(req.params.id));
});

/** Regenerates the schedule from the loan parameters (overwrites imported data). */
router.post('/:id/generate', (req, res) => {
  const loan = getLoan(req.params.id);
  const rows = computeSchedule(loan);
  if (!rows.length) throw httpError(400, 'Paramètres du prêt incomplets (capital, durée, date de 1re échéance)');
  replaceSchedule(loan.id, rows);
  res.json({ count: rows.length });
});

/** Imports the bank amortization table (CSV text in body.csv). */
router.post('/:id/import', (req, res) => {
  const loan = getLoan(req.params.id);
  let rows;
  try {
    rows = parseScheduleCsv(req.body?.csv, loan.principal);
  } catch (err) {
    throw httpError(400, err.message);
  }
  replaceSchedule(loan.id, rows);
  const first = rows[0];
  db.prepare('UPDATE loans SET duration_months = ?, start_date = ? WHERE id = ?').run(rows.length, first.due_date, loan.id);
  res.json({ count: rows.length });
});

router.put('/:id/installments/:instId', (req, res) => {
  getLoan(req.params.id);
  const inst = db.prepare('SELECT * FROM loan_installments WHERE id = ? AND loan_id = ?').get(req.params.instId, req.params.id);
  if (!inst) throw httpError(404, 'Échéance introuvable');
  const next = { ...inst };
  for (const k of ['payment', 'principal', 'interest', 'insurance', 'remaining']) {
    if (req.body?.[k] !== undefined) {
      const v = Number(req.body[k]);
      if (!Number.isFinite(v)) throw httpError(400, `Valeur invalide : ${k}`);
      next[k] = v;
    }
  }
  if (req.body?.due_date) next.due_date = String(req.body.due_date);
  db.prepare('UPDATE loan_installments SET due_date = ?, payment = ?, principal = ?, interest = ?, insurance = ?, remaining = ? WHERE id = ?').run(
    next.due_date, next.payment, next.principal, next.interest, next.insurance, next.remaining, inst.id,
  );
  res.json(next);
});

export default router;
