import { Router } from 'express';
import { categoryLabel } from '../constants.js';
import { db, getSettings } from '../db.js';
import { buildRegularization, streamPdf } from '../pdf.js';
import { daysBetween, httpError, num, round2, str } from '../util.js';
import { signaturePath } from './settings.js';

const router = Router();

const SELECT = `SELECT g.*, t.first_name, t.last_name, p.name AS property_name
  FROM regularizations g
  JOIN tenants t ON t.id = g.tenant_id
  JOIN properties p ON p.id = g.property_id`;

const STATUSES = ['brouillon', 'envoyée', 'réglée'];

const parseRow = (row) => (row ? { ...row, details: JSON.parse(row.details || '{}') } : row);
const getOne = (id) => parseRow(db.prepare(`${SELECT} WHERE g.id = ?`).get(id));

/** Computes the expected charge regularization of a tenant for a calendar year. */
export function computeRegularization(tenantId, year) {
  const tenant = db.prepare('SELECT * FROM tenants WHERE id = ?').get(tenantId);
  if (!tenant) throw httpError(404, 'Locataire introuvable');
  year = Math.trunc(Number(year));
  if (!(year > 1900 && year < 3000)) throw httpError(400, 'Année invalide');

  const yearStart = `${year}-01-01`;
  const yearEnd = `${year}-12-31`;
  const start = tenant.lease_start && tenant.lease_start > yearStart ? tenant.lease_start : yearStart;
  const end = tenant.lease_end && tenant.lease_end < yearEnd ? tenant.lease_end : yearEnd;
  if (start > end) throw httpError(400, `Le locataire n'occupait pas le logement en ${year}`);

  const yearDays = daysBetween(yearStart, yearEnd) + 1;
  const occupancyDays = daysBetween(start, end) + 1;
  const ratio = occupancyDays / yearDays;

  const provisions = db
    .prepare('SELECT COALESCE(SUM(charges_amount), 0) AS total FROM rent_payments WHERE tenant_id = ? AND substr(period, 1, 4) = ?')
    .get(tenant.id, String(year)).total;

  const rows = db
    .prepare(
      `SELECT category, SUM(recoverable_amount) AS total FROM expenses
       WHERE property_id = ? AND substr(date, 1, 4) = ? AND recoverable_amount <> 0
       GROUP BY category ORDER BY category`,
    )
    .all(tenant.property_id, String(year));

  const lines = rows.map((r) => ({
    label: categoryLabel(r.category),
    total: round2(r.total),
    share: round2(r.total * ratio),
  }));
  const actual = round2(lines.reduce((s, l) => s + l.share, 0));
  const annualTotal = rows.reduce((s, r) => s + r.total, 0);

  return {
    tenant_id: tenant.id,
    property_id: tenant.property_id,
    year,
    period_start: start,
    period_end: end,
    provisions: round2(provisions),
    actual_charges: actual,
    balance: round2(actual - provisions),
    new_provision: annualTotal > 0 ? round2(annualTotal / 12) : null,
    current_provision: tenant.charges_amount,
    details: { lines, occupancy_days: occupancyDays, year_days: yearDays },
  };
}

function normalize(body, base = {}) {
  const lines = Array.isArray(body.details?.lines ?? body.lines) ? (body.details?.lines ?? body.lines) : base.details?.lines || [];
  const cleanLines = lines
    .map((l) => ({ label: str(l.label) || 'Charge', total: round2(num(l.total)), share: round2(num(l.share)) }))
    .filter((l) => l.total !== 0 || l.share !== 0);
  const provisions = round2(num(body.provisions ?? base.provisions));
  const actual = round2(cleanLines.reduce((s, l) => s + l.share, 0));
  const status = body.status ?? base.status ?? 'brouillon';
  if (!STATUSES.includes(status)) throw httpError(400, 'Statut invalide');
  let newProvision;
  if (body.new_provision === undefined) newProvision = base.new_provision ?? null;
  else if (body.new_provision === '' || body.new_provision === null) newProvision = null;
  else newProvision = round2(num(body.new_provision));
  return {
    period_start: str(body.period_start) ?? base.period_start,
    period_end: str(body.period_end) ?? base.period_end,
    provisions,
    actual_charges: actual,
    balance: round2(actual - provisions),
    new_provision: newProvision,
    details: JSON.stringify({
      ...(base.details || {}),
      ...(body.details || {}),
      lines: cleanLines,
    }),
    status,
    notes: body.notes !== undefined ? str(body.notes) : base.notes ?? null,
  };
}

router.get('/', (req, res) => {
  const where = [];
  const params = [];
  if (req.query.property_id) {
    where.push('g.property_id = ?');
    params.push(req.query.property_id);
  }
  if (req.query.tenant_id) {
    where.push('g.tenant_id = ?');
    params.push(req.query.tenant_id);
  }
  const rows = db.prepare(`${SELECT}${where.length ? ` WHERE ${where.join(' AND ')}` : ''} ORDER BY g.year DESC, t.last_name`).all(...params);
  res.json(rows.map(parseRow));
});

router.get('/preview', (req, res) => {
  res.json(computeRegularization(req.query.tenant_id, req.query.year));
});

router.get('/:id', (req, res) => {
  const row = getOne(req.params.id);
  if (!row) throw httpError(404, 'Régularisation introuvable');
  res.json(row);
});

function applyProvision(tenantId, value) {
  if (value > 0) db.prepare('UPDATE tenants SET charges_amount = ? WHERE id = ?').run(value, tenantId);
}

router.post('/', (req, res) => {
  const body = req.body || {};
  const base = computeRegularization(body.tenant_id, body.year);
  const data = normalize(body, base);
  const info = db
    .prepare(
      `INSERT INTO regularizations (property_id, tenant_id, year, period_start, period_end, provisions, actual_charges, balance, new_provision, details, status, notes)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(base.property_id, base.tenant_id, base.year, data.period_start, data.period_end, data.provisions, data.actual_charges, data.balance, data.new_provision, data.details, data.status, data.notes);
  if (body.apply_new_provision) applyProvision(base.tenant_id, data.new_provision);
  res.status(201).json(getOne(info.lastInsertRowid));
});

router.put('/:id', (req, res) => {
  const existing = getOne(req.params.id);
  if (!existing) throw httpError(404, 'Régularisation introuvable');
  const data = normalize(req.body || {}, existing);
  db.prepare(
    `UPDATE regularizations SET period_start = ?, period_end = ?, provisions = ?, actual_charges = ?, balance = ?,
       new_provision = ?, details = ?, status = ?, notes = ? WHERE id = ?`,
  ).run(data.period_start, data.period_end, data.provisions, data.actual_charges, data.balance, data.new_provision, data.details, data.status, data.notes, existing.id);
  if (req.body?.apply_new_provision) applyProvision(existing.tenant_id, data.new_provision);
  res.json(getOne(existing.id));
});

router.delete('/:id', (req, res) => {
  const info = db.prepare('DELETE FROM regularizations WHERE id = ?').run(req.params.id);
  if (!info.changes) throw httpError(404, 'Régularisation introuvable');
  res.status(204).end();
});

router.get('/:id/pdf', (req, res) => {
  const reg = getOne(req.params.id);
  if (!reg) throw httpError(404, 'Régularisation introuvable');
  const tenant = db.prepare('SELECT * FROM tenants WHERE id = ?').get(reg.tenant_id);
  const property = db.prepare('SELECT * FROM properties WHERE id = ?').get(reg.property_id);
  streamPdf(res, `regularisation-charges-${reg.year}-${tenant.last_name}.pdf`, (doc) =>
    buildRegularization(doc, { settings: getSettings(), tenant, property, reg, signaturePath: signaturePath() }),
  );
});

export default router;
