import { crudRouter } from '../crud.js';
import { db, getSettings } from '../db.js';
import { buildReceipt, streamPdf } from '../pdf.js';
import { httpError, round2 } from '../util.js';
import { signaturePath } from './settings.js';

const PERIOD_RE = /^\d{4}-\d{2}$/;

function tenantFor(id) {
  const tenant = db.prepare('SELECT * FROM tenants WHERE id = ?').get(id);
  if (!tenant) throw httpError(400, 'Locataire introuvable');
  return tenant;
}

const router = crudRouter({
  table: 'rent_payments',
  alias: 'r',
  select: `SELECT r.*, t.first_name, t.last_name, p.name AS property_name
    FROM rent_payments r
    JOIN tenants t ON t.id = r.tenant_id
    JOIN properties p ON p.id = r.property_id`,
  fields: {
    tenant_id: { type: 'int', required: true, label: 'Locataire' },
    period: { type: 'period', required: true, label: 'Période' },
    rent_amount: { type: 'number', label: 'Loyer' },
    charges_amount: { type: 'number', label: 'Charges' },
    paid_amount: { type: 'number', label: 'Montant payé' },
    payment_date: { type: 'date', label: 'Date de paiement' },
    method: { type: 'text' },
    notes: { type: 'text' },
  },
  filters: [
    { param: 'property_id', sql: 'r.property_id = ?' },
    { param: 'tenant_id', sql: 'r.tenant_id = ?' },
    { param: 'year', sql: 'substr(r.period, 1, 4) = ?' },
  ],
  orderBy: 'r.period DESC, t.last_name',
  beforeSave: (data, existing) => {
    const tenant = tenantFor(data.tenant_id ?? existing.tenant_id);
    data.property_id = tenant.property_id;
    if (!existing) {
      if (data.rent_amount == null) data.rent_amount = tenant.rent_amount;
      if (data.charges_amount == null) data.charges_amount = tenant.charges_amount;
      if (data.paid_amount == null) data.paid_amount = round2(data.rent_amount + data.charges_amount);
    } else {
      for (const k of ['rent_amount', 'charges_amount', 'paid_amount']) if (k in data && data[k] == null) data[k] = 0;
    }
    return data;
  },
});

/** Records a full payment for every tenant of the property whose lease covers the period and who has no payment yet. */
router.post('/bulk', (req, res) => {
  const { property_id, period, payment_date, method } = req.body || {};
  if (!property_id) throw httpError(400, 'Champ requis : Bien');
  if (!PERIOD_RE.test(period || '')) throw httpError(400, 'Période invalide (AAAA-MM)');
  const monthStart = `${period}-01`;
  const monthEnd = `${period}-31`;
  const tenants = db
    .prepare(
      `SELECT * FROM tenants t WHERE t.property_id = ?
        AND (t.lease_start IS NULL OR t.lease_start <= ?)
        AND (t.lease_end IS NULL OR t.lease_end >= ?)
        AND NOT EXISTS (SELECT 1 FROM rent_payments r WHERE r.tenant_id = t.id AND r.period = ?)`,
    )
    .all(property_id, monthEnd, monthStart, period);
  const insert = db.prepare(
    `INSERT INTO rent_payments (tenant_id, property_id, period, rent_amount, charges_amount, paid_amount, payment_date, method)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
  );
  db.transaction(() => {
    for (const t of tenants) {
      insert.run(t.id, t.property_id, period, t.rent_amount, t.charges_amount, round2(t.rent_amount + t.charges_amount), payment_date || null, method || null);
    }
  })();
  res.json({ created: tenants.length });
});

router.get('/:id/receipt.pdf', (req, res) => {
  const payment = db.prepare('SELECT * FROM rent_payments WHERE id = ?').get(req.params.id);
  if (!payment) throw httpError(404, 'Paiement introuvable');
  const tenant = db.prepare('SELECT * FROM tenants WHERE id = ?').get(payment.tenant_id);
  const property = db.prepare('SELECT * FROM properties WHERE id = ?').get(payment.property_id);
  const full = payment.paid_amount >= payment.rent_amount + payment.charges_amount - 0.005;
  const name = `${full ? 'quittance' : 'recu'}-${payment.period}-${tenant.last_name}.pdf`;
  streamPdf(res, name, (doc) =>
    buildReceipt(doc, { settings: getSettings(), tenant, property, payment, signaturePath: signaturePath() }),
  );
});

export default router;
