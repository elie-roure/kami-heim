import assert from 'node:assert/strict';
import { test } from 'node:test';
import { computeSchedule, parseScheduleCsv } from '../src/loan.js';
import { addMonths, amountToWords, numberToWords } from '../src/util.js';

test('numberToWords handles French rules', () => {
  assert.equal(numberToWords(0), 'zéro');
  assert.equal(numberToWords(21), 'vingt et un');
  assert.equal(numberToWords(71), 'soixante et onze');
  assert.equal(numberToWords(80), 'quatre-vingts');
  assert.equal(numberToWords(81), 'quatre-vingt-un');
  assert.equal(numberToWords(99), 'quatre-vingt-dix-neuf');
  assert.equal(numberToWords(200), 'deux cents');
  assert.equal(numberToWords(250), 'deux cent cinquante');
  assert.equal(numberToWords(1000), 'mille');
  assert.equal(numberToWords(200000), 'deux cent mille');
  assert.equal(numberToWords(80000), 'quatre-vingt mille');
  assert.equal(numberToWords(1250), 'mille deux cent cinquante');
});

test('amountToWords adds euros and cents', () => {
  assert.equal(amountToWords(850), 'huit cent cinquante euros');
  assert.equal(amountToWords(1), 'un euro');
  assert.equal(amountToWords(712.5), 'sept cent douze euros et cinquante centimes');
});

test('addMonths clamps to month end', () => {
  assert.equal(addMonths('2024-01-31', 1), '2024-02-29');
  assert.equal(addMonths('2024-11-05', 3), '2025-02-05');
});

test('computeSchedule amortizes the full principal', () => {
  const rows = computeSchedule({ principal: 200000, annual_rate: 3.5, duration_months: 240, start_date: '2024-02-05', insurance_monthly: 20 });
  assert.equal(rows.length, 240);
  assert.equal(rows[0].interest, 583.33);
  assert.equal(rows[0].payment, round(rows[0].principal + rows[0].interest + 20));
  assert.equal(rows.at(-1).remaining, 0);
  const totalPrincipal = rows.reduce((s, r) => s + r.principal, 0);
  assert.ok(Math.abs(totalPrincipal - 200000) < 0.01);
  assert.equal(rows.at(-1).due_date, '2044-01-05');
});

test('computeSchedule supports zero rate', () => {
  const rows = computeSchedule({ principal: 1200, annual_rate: 0, duration_months: 12, start_date: '2024-01-01' });
  assert.equal(rows[0].principal, 100);
  assert.equal(rows.at(-1).remaining, 0);
});

test('parseScheduleCsv reads a French bank export', () => {
  const csv = [
    'N° échéance;Date d\'échéance;Montant échéance;Capital amorti;Intérêts;Assurance;Capital restant dû',
    '1;05/02/2024;1 180,61 €;577,28;583,33;20,00;199 422,72',
    '2;05/03/2024;1 180,61 €;578,96;581,65;20,00;198 843,76',
  ].join('\r\n');
  const rows = parseScheduleCsv(csv);
  assert.equal(rows.length, 2);
  assert.deepEqual(rows[0], {
    number: 1, due_date: '2024-02-05', principal: 577.28, interest: 583.33, insurance: 20, payment: 1180.61, remaining: 199422.72,
  });
});

test('parseScheduleCsv computes missing columns', () => {
  const csv = 'date,capital,interets\n2024-01-10,100.5,10\n2024-02-10,101,9.5';
  const rows = parseScheduleCsv(csv, 1000);
  assert.equal(rows[0].payment, 110.5);
  assert.equal(rows[0].remaining, 899.5);
  assert.equal(rows[1].remaining, 798.5);
});

test('parseScheduleCsv rejects missing columns', () => {
  assert.throws(() => parseScheduleCsv('foo;bar\n1;2'), /date/);
});

function round(n) {
  return Math.round(n * 100) / 100;
}
