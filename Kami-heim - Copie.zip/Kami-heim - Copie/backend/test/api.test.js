﻿import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { after, before, test } from 'node:test';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'kamiheim-test-'));
const port = 3900 + Math.floor(Math.random() * 90);
const base = `http://localhost:${port}/api`;
let server;

async function api(method, url, body) {
  const res = await fetch(base + url, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  const type = res.headers.get('content-type') || '';
  const data = type.includes('json') ? await res.json() : Buffer.from(await res.arrayBuffer());
  return { status: res.status, data, type };
}

before(async () => {
  server = spawn(process.execPath, ['src/server.js'], {
    cwd: root,
    env: { ...process.env, PORT: String(port), DATA_DIR: dataDir, PUBLIC_DIR: path.join(dataDir, 'nope') },
    stdio: 'pipe',
  });
  for (let i = 0; i < 50; i++) {
    try {
      const r = await fetch(`${base}/health`);
      if (r.ok) return;
    } catch {
      // not ready yet
    }
    await new Promise((r) => setTimeout(r, 100));
  }
  throw new Error('server did not start');
});

after(() => {
  server?.kill();
  setTimeout(() => fs.rmSync(dataDir, { recursive: true, force: true }), 300);
});

test('full rental workflow', async () => {
  let r = await api('PUT', '/settings', { owner_name: 'Jean Dupont', owner_city: 'Lyon', owner_address: '1 rue A' });
  assert.equal(r.data.owner_name, 'Jean Dupont');

  r = await api('POST', '/properties', { name: 'Appartement T2', address: '10 rue de la Paix', postal_code: '69001', city: 'Lyon', purchase_price: '180000', notary_fees: 14000 });
  assert.equal(r.status, 201);
  const property = r.data;

  r = await api('POST', '/properties', { address: 'x' });
  assert.equal(r.status, 400);

  r = await api('POST', '/tenants', { property_id: property.id, first_name: 'Marie', last_name: 'Martin', lease_start: '2025-03-15', rent_amount: 700, charges_amount: 50 });
  assert.equal(r.status, 201);
  const tenant = r.data;

  r = await api('POST', '/rents', { tenant_id: tenant.id, period: '2025-04', payment_date: '2025-04-03', method: 'Virement' });
  assert.equal(r.status, 201);
  assert.equal(r.data.paid_amount, 750);
  assert.equal(r.data.property_id, property.id);
  const payment = r.data;

  r = await api('POST', '/rents', { tenant_id: tenant.id, period: '2025-04' });
  assert.equal(r.status, 409);

  r = await api('POST', '/rents/bulk', { property_id: property.id, period: '2025-05', payment_date: '2025-05-02' });
  assert.equal(r.data.created, 1);
  r = await api('POST', '/rents', { tenant_id: tenant.id, period: '2025-06', paid_amount: 400 });
  const partial = r.data;

  r = await api('GET', `/rents?property_id=${property.id}&year=2025`);
  assert.equal(r.data.length, 3);
  assert.equal(r.data[0].last_name, 'Martin');

  r = await api('GET', `/rents/${payment.id}/receipt.pdf`);
  assert.equal(r.status, 200);
  assert.equal(r.type, 'application/pdf');
  assert.equal(r.data.subarray(0, 4).toString(), '%PDF');
  r = await api('GET', `/rents/${partial.id}/receipt.pdf`);
  assert.equal(r.status, 200);

  r = await api('POST', '/expenses/recurring', { property_id: property.id, date: '2025-01-01', category: 'copropriete', label: 'Appel de fonds', amount: 300, recoverable_amount: 120, count: 4, interval_months: 3 });
  assert.equal(r.data.created, 4);
  r = await api('POST', '/expenses', { property_id: property.id, date: '2025-10-15', category: 'taxe_fonciere', amount: 900, recoverable_amount: 150 });
  assert.equal(r.status, 201);
  r = await api('GET', `/expenses?property_id=${property.id}&year=2025`);
  assert.equal(r.data.length, 5);

  r = await api('GET', `/regularizations/preview?tenant_id=${tenant.id}&year=2025`);
  assert.equal(r.status, 200);
  assert.equal(r.data.period_start, '2025-03-15');
  assert.equal(r.data.provisions, 150);
  assert.equal(r.data.details.lines.length, 2);
  assert.equal(r.data.details.occupancy_days, 292);
  const preview = r.data;

  r = await api('POST', '/regularizations', { ...preview, apply_new_provision: true });
  assert.equal(r.status, 201);
  const reg = r.data;
  assert.equal(reg.balance, Math.round((reg.actual_charges - 150) * 100) / 100);
  r = await api('GET', `/tenants/${tenant.id}`);
  assert.equal(r.data.charges_amount, preview.new_provision);
  r = await api('GET', `/regularizations/${reg.id}/pdf`);
  assert.equal(r.type, 'application/pdf');

  r = await api('POST', '/loans', { property_id: property.id, name: 'Prêt immo', principal: 150000, annual_rate: 3.2, duration_months: 240, start_date: '2025-01-05', insurance_monthly: 15 });
  assert.equal(r.status, 201);
  assert.equal(r.data.installments_count, 240);
  const loan = r.data;
  r = await api('POST', `/loans/${loan.id}/import`, { csv: 'date;capital;interets;assurance\n05/01/2025;500;400;15\n05/02/2025;501;399;15' });
  assert.equal(r.data.count, 2);
  r = await api('GET', `/loans/${loan.id}/installments`);
  assert.equal(r.data.length, 2);
  assert.equal(r.data[1].remaining, 148999);
  r = await api('PUT', `/loans/${loan.id}`, { duration_months: 240 });
  assert.equal(r.data.duration_months, 240);
  r = await api('POST', `/loans/${loan.id}/generate`);
  assert.equal(r.data.count, 240);

  r = await api('GET', `/dashboard?property_id=${property.id}&year=2025`);
  assert.equal(r.status, 200);
  assert.equal(r.data.totals.revenue, 1900);
  assert.equal(r.data.totals.expenses, 2100);
  assert.ok(r.data.totals.interest > 0);
  assert.ok(r.data.unpaid.some((u) => u.period === '2025-06' && u.missing === 350));
  assert.ok(r.data.unpaid.some((u) => u.period === '2025-03'));
  assert.equal(r.data.gross_yield, Math.round(((700 * 12) / 194000) * 10000) / 100);

  r = await api('GET', '/dashboard');
  assert.equal(r.status, 200);

  const form = new FormData();
  form.append('property_id', String(property.id));
  form.append('tenant_id', String(tenant.id));
  form.append('category', 'bail');
  form.append('file', new Blob(['hello'], { type: 'text/plain' }), 'bail signé.txt');
  let res = await fetch(`${base}/documents`, { method: 'POST', body: form });
  assert.equal(res.status, 201);
  const doc = await res.json();
  assert.equal(doc.title, 'bail signé.txt');
  res = await fetch(`${base}/documents/${doc.id}/file`);
  assert.equal(await res.text(), 'hello');

  res = await fetch(`${base}/backup`);
  assert.equal(res.status, 200);
  assert.equal((await res.arrayBuffer()).byteLength > 100, true);

  r = await api('DELETE', `/tenants/${tenant.id}`);
  assert.equal(r.status, 204);
  r = await api('GET', `/documents?property_id=${property.id}`);
  assert.equal(r.data.length, 0);
  r = await api('GET', `/rents?property_id=${property.id}`);
  assert.equal(r.data.length, 0);
});
