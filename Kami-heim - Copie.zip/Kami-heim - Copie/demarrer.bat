@echo off
REM Lance Kami-heim avec Docker puis ouvre le navigateur
cd /d "%~dp0"
docker compose up -d --build
if errorlevel 1 (
  echo.
  echo Echec du demarrage. Verifiez que Docker Desktop est lance.
  pause
  exit /b 1
)
timeout /t 3 /nobreak >nul
start "" http://localhost:8080
