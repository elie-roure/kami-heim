# AGENTS.md — Kami-heim

Contexte pour les assistants IA travaillant sur ce dépôt. Guide utilisateur (installation, usage, format CSV) : voir [README.md](README.md).

## Objectif du projet

Application **locale** de gestion locative pour un propriétaire bailleur particulier (France), utilisable sur plusieurs biens :
locataires + documents, saisie des loyers par mois, **quittances PDF**, charges/appels de fonds du **syndic**,
**régularisation annuelle des charges**, **tableau d'amortissement du prêt**, et **tableau de bord** (ce que le bien coûte / rapporte).
Lancement prévu via **Docker** (`docker compose up -d --build` → http://localhost:8080), données persistées dans `./data`.

- Interface et messages d'erreur **en français** ; identifiants de code, noms de tables/colonnes **en anglais**.
- Mono-utilisateur, pas de comptes. Authentification HTTP Basic optionnelle via `APP_USER` / `APP_PASSWORD`.

## Architecture

```
backend/   Node.js ≥ 20, ESM, Express 4, better-sqlite3 (synchrone), multer 2, pdfkit, archiver
frontend/  Vue 3 (<script setup>), vue-router 4, Vite 6, chart.js 4 + vue-chartjs — aucune lib UI, CSS maison
Dockerfile multi-étapes : build Vite → deps backend (outils de compilation) → image finale node:22-bookworm-slim
```

En production, **un seul process** : Express sert l'API sous `/api` et le frontend compilé (`PUBLIC_DIR`) avec fallback SPA.
En dev, Vite (port 5173) proxifie `/api` vers le backend (port 3000).

### Backend (`backend/src`)

| Fichier | Rôle |
|---|---|
| `server.js` | App Express, montage des routes, `/api/meta`, `/api/backup` (zip base + uploads), basic auth, gestion d'erreurs centralisée |
| `db.js` | Connexion SQLite (`DATA_DIR/kamiheim.db`, WAL, `foreign_keys = ON`) et **schéma** (`CREATE TABLE IF NOT EXISTS`) |
| `crud.js` | `parseFields(schema, body, {partial})` (validation/typage) et `crudRouter({...})` (GET liste/un, POST, PUT partiel, DELETE) avec hooks `beforeSave`, `afterSave`, `beforeDelete` |
| `constants.js` | Catégories de dépenses, de documents, modes de paiement (servis au front par `/api/meta`) |
| `util.js` | `num`, `str`, `round2`, `addMonths`, `daysBetween`, `formatEur`, `amountToWords` (montant en lettres FR), `monthLabel` |
| `pdf.js` | `buildReceipt` (quittance / reçu partiel), `buildRegularization` (décompte de charges), helpers de mise en page |
| `loan.js` | `computeSchedule` (prêt amortissable à mensualités constantes) et `parseScheduleCsv` (import tableau bancaire) |
| `upload.js` | Stockage multer dans `DATA_DIR/uploads` (noms UUID), `fixFileName` (latin1→UTF-8), `removeUpload` |
| `routes/*.js` | Une route par domaine (voir API ci-dessous) |

### Frontend (`frontend/src`)

- `store.js` : état global réactif (`properties`, `propertyId` sélectionné persisté en localStorage, `meta`, toasts) ; `attempt(fn, msgSuccès)` exécute une action async et affiche l'erreur en toast.
- `api.js` : wrapper `fetch` (`api.get/post/put/del`, gère `FormData`) + `qs()` pour les query strings.
- `format.js` : formatage FR (`eur`, `date`, `periodLabel`, `pct`), `leaseStatus`, `leaseCovers(tenant, 'YYYY-MM')`, `readTextFile` (UTF-8 puis Windows-1252).
- `App.vue` : layout (sidebar + sélecteur de bien). `<router-view>` est **keyé sur `store.propertyId`** → changer de bien remonte la vue (chaque vue charge ses données dans `onMounted`).
- `views/` : une vue par page (Dashboard, Properties, Tenants, TenantDetail, Rents, Expenses, Regularization, Loans, Documents, Settings).
- `components/` : `Modal`, `YearSelect`, `TenantForm`, `DocumentList` (upload + liste, réutilisé par Documents et TenantDetail).
- Chart.js est enregistré globalement dans `main.js` (`Chart.register(...registerables)`).

## Modèle de données (SQLite)

| Table | Points clés |
|---|---|
| `settings` | clé/valeur : `owner_name`, `owner_address`, `owner_postal_code`, `owner_city`, `owner_email`, `owner_phone`, `signature_file` |
| `properties` | bien ; `purchase_price` + `notary_fees` = prix de revient (rendement) |
| `tenants` | `property_id`, `lease_start`/`lease_end` (NULL = en cours), `rent_amount` (HC), `charges_amount` (provision), `deposit` |
| `documents` | fichier dans `uploads/` ; `property_id` obligatoire, `tenant_id` optionnel ; `category` ∈ `DOCUMENT_CATEGORIES` |
| `rent_payments` | un enregistrement par locataire et par mois : **`UNIQUE(tenant_id, period)`** ; `period` = `YYYY-MM` ; `paid_amount` < dû ⇒ paiement partiel |
| `expenses` | dépenses du propriétaire ; `amount` (peut être négatif = avoir) et `recoverable_amount` (part refacturable au locataire) |
| `regularizations` | `UNIQUE(tenant_id, year)` ; `details` = JSON `{ lines:[{label,total,share}], occupancy_days, year_days }` ; `status` ∈ `brouillon`/`envoyée`/`réglée` |
| `loans` / `loan_installments` | échéancier complet stocké en base (généré ou importé) |

Conventions de données : dates en texte ISO `YYYY-MM-DD`, périodes `YYYY-MM`, montants `REAL` en euros arrondis avec `round2`.
Suppressions en cascade via clés étrangères ; les **fichiers** des documents sont supprimés explicitement dans les hooks `beforeDelete` (biens, locataires) et la route documents.

## API (préfixe `/api`)

- CRUD standard (`GET /`, `GET /:id`, `POST /`, `PUT /:id`, `DELETE /:id`) via `crudRouter` : `properties`, `tenants?property_id`, `rents?property_id&tenant_id&year`, `expenses?property_id&year&category`, `loans?property_id`.
- `rents` : `POST /bulk {property_id, period, payment_date, method}` (paie le mois pour tous les baux actifs sans paiement), `GET /:id/receipt.pdf`. À la création, loyer/charges/montant payé sont **pré-remplis depuis le locataire** s'ils sont absents ; `property_id` est toujours déduit du locataire.
- `expenses` : `POST /recurring {...dépense, count, interval_months}`.
- `documents` : `GET /`, `POST /` (multipart, champ `file`), `PUT /:id`, `GET /:id/file[?download=1]`, `DELETE /:id`.
- `regularizations` : `GET /preview?tenant_id&year` (calcul), `POST /` (création, `apply_new_provision` met à jour la provision du locataire), `PUT /:id`, `DELETE /:id`, `GET /:id/pdf`.
- `loans` : `GET /:id/installments`, `POST /:id/generate` (recalcule depuis les paramètres), `POST /:id/import {csv}` (remplace l'échéancier **et met à jour `duration_months`/`start_date`**), `PUT /:id/installments/:instId`. La création d'un prêt génère automatiquement l'échéancier.
- `dashboard?property_id&year` (sans `property_id` = tous les biens), `settings` (+ `/signature` POST/GET/DELETE), `meta`, `backup`, `health`.

Erreurs : JSON `{ error: "message en français" }` ; `httpError(status, msg)` ; contraintes SQLite traduites (UNIQUE → 409).

## Règles métier

- **Quittance** (art. 21 loi n° 89-462) : émise seulement si `paid_amount ≥ loyer + charges` ; sinon PDF « Reçu de paiement partiel ». Montant en lettres via `amountToWords`.
- **Régularisation** (art. 23) : période = intersection année civile × bail ; prorata = jours d'occupation / jours de l'année ;
  charges réelles = Σ `recoverable_amount` des dépenses de l'année (par catégorie) × prorata ; provisions = Σ `charges_amount` des loyers saisis de l'année ;
  solde = réel − provisions (> 0 : le locataire doit ; < 0 : à rembourser) ; nouvelle provision suggérée = total annuel récupérable / 12. Les lignes restent éditables côté UI.
- **Dashboard** : un paiement est réparti entre loyer et charges **au prorata** du dû ; pour l'**année en cours**, les totaux/KPI s'arrêtent au mois courant (`months_counted`) alors que la série `months` couvre les 12 mois (projection des échéances de prêt) ; l'historique annuel est borné à la fin du mois courant.
  Résultat = revenus − dépenses − intérêts − assurance ; cash-flow = résultat − capital remboursé ; rendement brut = loyers HC annuels des baux actifs / prix de revient.
- **Impayés** : pour chaque mois couvert par un bail (jusqu'au mois courant), dû = montants du paiement s'il existe, sinon ceux du locataire.

## Build et tests

```bash
cd backend  && npm install && npm test      # node --test : unitaires + intégration API
cd backend  && npm run dev                  # API sur :3000 (données dans backend/data)
cd frontend && npm install && npm run dev   # UI sur :5173 (proxy /api)
cd frontend && npm run build                # doit passer sans erreur
docker compose up -d --build                # production sur :8080
```

- `test/api.test.js` lance le vrai serveur sur un port aléatoire avec un `DATA_DIR` temporaire et parcourt le workflow complet : **à mettre à jour à chaque changement d'API ou de calcul**.
- Pas de linter configuré ; style : ESM, 2 espaces, guillemets simples, point-virgule.

## Pièges à connaître

- **Pas de système de migration** : le schéma utilise `CREATE TABLE IF NOT EXISTS`. Pour ajouter une colonne sur une base existante, ajouter une migration idempotente dans `db.js` (vérifier `PRAGMA table_info(...)` puis `ALTER TABLE ... ADD COLUMN`). Ne jamais casser les bases existantes dans `data/`.
- **Express 4** : les handlers sont synchrones (better-sqlite3) et les exceptions sont attrapées ; un handler `async` doit appeler `next(err)` lui-même.
- **Ordre des routes** : `crudRouter` déclare `/:id` ; les routes spécifiques ajoutées ensuite doivent avoir plusieurs segments (`/:id/pdf`) ou une méthode non utilisée par le CRUD (`POST /bulk`).
- **PDFKit** utilise les polices standard (encodage WinAnsi) : éviter les caractères hors WinAnsi (ex. espace fine insécable U+202F produite par `Intl` → utiliser `formatEur` qui la remplace).
- **Noms de fichiers uploadés** : busboy les décode en latin1 → toujours passer par `fixFileName`.
- Les noms de fichiers stockés sont des UUID ; ne jamais construire un chemin à partir d'une saisie utilisateur (`uploadPath` applique `basename`).
- Le **lockfile frontend** doit contenir les binaires optionnels Linux (`@rollup/rollup-linux-*`, `@esbuild/linux-*`) pour que `npm ci` fonctionne dans Docker.
- Le formulaire du locataire envoie tout l'objet ; `parseFields` ignore les clés inconnues (ne pas s'appuyer sur un rejet).

## Environnement de développement actuel

Sur le poste d'origine (Windows), **ni Node.js ni Docker ne sont installés globalement** : une version portable de Node 22 a été utilisée pour construire et tester.
L'application peut aussi tourner sans Docker : build du frontend puis `node backend/src/server.js` avec `PORT=8080`, `DATA_DIR=<projet>/data`
(Express sert `frontend/dist` par défaut).

## Pistes d'évolution identifiées (non implémentées)

Restauration de sauvegarde depuis l'UI, envoi des quittances par e-mail, révision annuelle du loyer (IRL), aide à la déclaration fiscale (2044 / micro-foncier), différé et taux variable pour le prêt, migrations de schéma versionnées.
