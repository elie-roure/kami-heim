<template>
  <div>
    <div class="page-header">
      <div>
        <h1>Locataires</h1>
        <div class="subtitle">{{ currentProperty?.name }}</div>
      </div>
      <button class="btn" @click="editing = {}">＋ Nouveau locataire</button>
    </div>

    <div class="card">
      <div v-if="!tenants.length" class="empty">
        <div class="big">👤</div>
        Aucun locataire enregistré pour ce bien.
      </div>
      <div v-else class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Locataire</th>
              <th>Contact</th>
              <th>Bail</th>
              <th class="num">Loyer HC</th>
              <th class="num">Charges</th>
              <th class="num">Total</th>
              <th>Statut</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="t in tenants" :key="t.id" class="clickable" @click="open(t)">
              <td><strong>{{ tenantName(t) }}</strong></td>
              <td>
                <div>{{ t.email || '' }}</div>
                <div class="help">{{ t.phone || '' }}</div>
              </td>
              <td>{{ date(t.lease_start) }} → {{ t.lease_end ? date(t.lease_end) : 'en cours' }}</td>
              <td class="num">{{ eur(t.rent_amount) }}</td>
              <td class="num">{{ eur(t.charges_amount) }}</td>
              <td class="num"><strong>{{ eur(t.rent_amount + t.charges_amount) }}</strong></td>
              <td><span class="badge" :class="statusClass[leaseStatus(t)]">{{ LEASE_STATUS_LABELS[leaseStatus(t)] }}</span></td>
              <td class="actions" @click.stop>
                <button class="btn ghost sm" @click="open(t)">Dossier</button>
                <button class="btn ghost sm" @click="editing = t">Modifier</button>
                <button class="btn ghost danger sm" @click="remove(t)">Supprimer</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <TenantForm v-if="editing" :tenant="editing" @close="editing = null" @saved="onSaved" />
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue';
import { useRouter } from 'vue-router';
import { api } from '../api.js';
import TenantForm from '../components/TenantForm.vue';
import { date, eur, LEASE_STATUS_LABELS, leaseStatus, tenantName } from '../format.js';
import { attempt, currentProperty, store } from '../store.js';

const router = useRouter();
const tenants = ref([]);
const editing = ref(null);
const statusClass = { active: 'success', upcoming: 'info', ended: '' };

async function load() {
  await attempt(async () => {
    tenants.value = await api.get(`/tenants?property_id=${store.propertyId}`);
  });
}

function open(t) {
  router.push(`/locataires/${t.id}`);
}

function onSaved() {
  editing.value = null;
  load();
}

async function remove(t) {
  if (!confirm(`Supprimer ${tenantName(t)} ainsi que ses loyers, documents et régularisations ?`)) return;
  if (await attempt(() => api.del(`/tenants/${t.id}`), 'Locataire supprimé')) load();
}

onMounted(load);
</script>
