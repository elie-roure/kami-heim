<template>
  <div>
    <div class="page-header">
      <div>
        <h1>Documents</h1>
        <div class="subtitle">{{ currentProperty?.name }} — bail, états des lieux, diagnostics, documents du syndic, factures…</div>
      </div>
    </div>
    <DocumentList :property-id="store.propertyId" />
  </div>
</template>

<script setup>
import DocumentList from '../components/DocumentList.vue';
import { currentProperty, store } from '../store.js';
</script>
