<template>
  <div>
    <div class="page-header">
      <div>
        <h1>Prêt immobilier</h1>
        <div class="subtitle">{{ currentProperty?.name }} — tableau d'amortissement</div>
      </div>
      <button class="btn" @click="openForm()">＋ Ajouter un prêt</button>
    </div>

    <div v-if="!loans.length" class="card empty">
      <div class="big">🏦</div>
      Aucun prêt enregistré.<br />
      <span class="help">Saisissez les caractéristiques du prêt pour calculer le tableau, puis importez si besoin le tableau exact de votre banque (CSV).</span>
    </div>

    <div class="grid grid-3">
      <div v-for="l in loans" :key="l.id" class="card" :style="l.id === selectedId ? 'outline: 2px solid var(--primary-light)' : ''">
        <div class="card-header">
          <h2>{{ l.name }}</h2>
          <span class="text-muted">{{ l.bank }}</span>
        </div>
        <dl class="dl">
          <dt>Capital emprunté</dt><dd>{{ eur(l.principal) }}</dd>
          <dt>Taux / durée</dt><dd>{{ pct(l.annual_rate) }} · {{ durationLabel(l.installments_count || l.duration_months) }}</dd>
          <dt>Mensualité</dt><dd>{{ eur(l.monthly_payment) }} <span class="help">(dont assurance {{ eur(l.insurance_monthly) }})</span></dd>
          <dt>Coût des intérêts</dt><dd>{{ eur(l.total_interest) }}</dd>
          <dt>Coût de l'assurance</dt><dd>{{ eur(l.total_insurance) }}</dd>
          <dt>Fin du prêt</dt><dd>{{ date(l.end_date) }}</dd>
          <dt>Capital restant dû</dt><dd><strong>{{ eur(remainingToday(l)) }}</strong></dd>
        </dl>
        <div class="progress" :title="`${progress(l)} % remboursé`"><div :style="{ width: `${progress(l)}%` }"></div></div>
        <div class="help">{{ progress(l) }} % du capital remboursé</div>
        <div class="toolbar" style="margin-top: 1rem">
          <button class="btn sm" @click="select(l.id)">Voir le tableau</button>
          <button class="btn secondary sm" @click="openForm(l)">Modifier</button>
          <button class="btn secondary sm" @click="pickCsv(l)">Importer CSV</button>
          <button class="btn ghost danger sm" @click="remove(l)">Supprimer</button>
        </div>
      </div>
    </div>
    <input ref="csvInput" type="file" accept=".csv,.txt,text/csv" style="display: none" @change="importCsv" />

    <template v-if="selected">
      <div class="grid grid-2">
        <div class="card">
          <h2>Capital restant dû</h2>
          <div class="chart-box small"><Line :data="remainingChart" :options="lineOptions" /></div>
        </div>
        <div class="card">
          <h2>Répartition annuelle des échéances</h2>
          <div class="chart-box small"><Bar :data="yearlyChart" :options="barOptions" /></div>
        </div>
      </div>

      <div class="card">
        <div class="card-header">
          <h2>Tableau d'amortissement — {{ selected.name }}</h2>
          <div class="toolbar">
            <button class="btn ghost sm" @click="expandAll">{{ expanded.size ? 'Tout replier' : 'Tout déplier' }}</button>
          </div>
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>N°</th>
                <th>Échéance</th>
                <th class="num">Mensualité</th>
                <th class="num">Capital</th>
                <th class="num">Intérêts</th>
                <th class="num">Assurance</th>
                <th class="num">Capital restant dû</th>
              </tr>
            </thead>
            <tbody>
              <template v-for="y in years" :key="y.year">
                <tr class="clickable" style="background: #f1f5f9" @click="toggle(y.year)">
                  <td colspan="2"><strong>{{ expanded.has(y.year) ? '▾' : '▸' }} {{ y.year }}</strong> <span class="help">({{ y.rows.length }} échéances)</span></td>
                  <td class="num"><strong>{{ eur(y.payment) }}</strong></td>
                  <td class="num">{{ eur(y.principal) }}</td>
                  <td class="num">{{ eur(y.interest) }}</td>
                  <td class="num">{{ eur(y.insurance) }}</td>
                  <td class="num">{{ eur(y.rows.at(-1).remaining) }}</td>
                </tr>
                <template v-if="expanded.has(y.year)">
                  <tr v-for="r in y.rows" :key="r.id" :class="{ highlight: r.due_date.slice(0, 7) === thisMonth }">
                    <td>{{ r.number }}</td>
                    <td>{{ date(r.due_date) }}</td>
                    <td class="num">{{ eur(r.payment) }}</td>
                    <td class="num">{{ eur(r.principal) }}</td>
                    <td class="num">{{ eur(r.interest) }}</td>
                    <td class="num">{{ eur(r.insurance) }}</td>
                    <td class="num">{{ eur(r.remaining) }}</td>
                  </tr>
                </template>
              </template>
            </tbody>
            <tfoot>
              <tr>
                <td colspan="2">Total</td>
                <td class="num">{{ eur(totals.payment) }}</td>
                <td class="num">{{ eur(totals.principal) }}</td>
                <td class="num">{{ eur(totals.interest) }}</td>
                <td class="num">{{ eur(totals.insurance) }}</td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    </template>

    <Modal v-if="form" :title="form.id ? 'Modifier le prêt' : 'Nouveau prêt'" @close="form = null">
      <form id="loan-form" class="form-grid" @submit.prevent="save">
        <label class="field"><span>Nom du prêt *</span><input v-model="form.name" required placeholder="Prêt immobilier principal" /></label>
        <label class="field"><span>Banque</span><input v-model="form.bank" /></label>
        <label class="field"><span>Capital emprunté (€) *</span><input v-model.number="form.principal" type="number" step="0.01" min="0" required /></label>
        <label class="field"><span>Taux annuel (%)</span><input v-model.number="form.annual_rate" type="number" step="0.001" min="0" /></label>
        <label class="field">
          <span>Durée (mois)</span><input v-model.number="form.duration_months" type="number" min="1" />
          <small>{{ durationLabel(form.duration_months) }}</small>
        </label>
        <label class="field"><span>Date de la 1re échéance *</span><input v-model="form.start_date" type="date" required /></label>
        <label class="field"><span>Assurance emprunteur / mois (€)</span><input v-model.number="form.insurance_monthly" type="number" step="0.01" min="0" /></label>
        <div class="field">
          <span>Mensualité estimée</span>
          <div style="padding-top: 0.5rem"><strong>{{ eur(estimate) }}</strong> <span class="help">assurance comprise</span></div>
        </div>
        <label class="field full"><span>Notes</span><input v-model="form.notes" /></label>
        <label v-if="form.id" class="checkbox full">
          <input v-model="form.regenerate" type="checkbox" /> Recalculer le tableau d'amortissement avec ces paramètres (remplace le tableau actuel)
        </label>
      </form>
      <div class="notice" style="margin-top: 1rem">
        Le tableau est calculé automatiquement (prêt amortissable à mensualités constantes). Pour obtenir les montants exacts
        (différé, taux variable…), importez ensuite le tableau fourni par votre banque au format CSV avec les colonnes
        <code>date ; capital ; intérêts ; assurance ; capital restant dû</code> (une ligne d'en-tête, séparateur « ; »).
      </div>
      <template #footer>
        <button class="btn secondary" type="button" @click="form = null">Annuler</button>
        <button class="btn" type="submit" form="loan-form">Enregistrer</button>
      </template>
    </Modal>
  </div>
</template>

<script setup>
import { Bar, Line } from 'vue-chartjs';
import { computed, onMounted, reactive, ref } from 'vue';
import { api } from '../api.js';
import Modal from '../components/Modal.vue';
import { currentPeriod, date, eur, eur0, pct, readTextFile, round2, todayIso } from '../format.js';
import { attempt, currentProperty, store } from '../store.js';

const loans = ref([]);
const selectedId = ref(null);
const installments = ref([]);
const expanded = reactive(new Set());
const form = ref(null);
const csvInput = ref(null);
const csvTarget = ref(null);
const thisMonth = currentPeriod();

const selected = computed(() => loans.value.find((l) => l.id === selectedId.value));

function durationLabel(months) {
  const m = Number(months) || 0;
  const y = Math.floor(m / 12);
  const r = m % 12;
  return [y ? `${y} an${y > 1 ? 's' : ''}` : '', r ? `${r} mois` : ''].filter(Boolean).join(' ') || '—';
}

function remainingToday(l) {
  if (l.remaining_today !== null && l.remaining_today !== undefined) return l.remaining_today;
  return l.principal;
}

const progress = (l) => (l.principal > 0 ? Math.max(0, Math.min(100, Math.round((1 - remainingToday(l) / l.principal) * 100))) : 0);

const estimate = computed(() => {
  const f = form.value;
  if (!f?.principal || !f.duration_months) return 0;
  const r = (f.annual_rate || 0) / 100 / 12;
  const base = r === 0 ? f.principal / f.duration_months : (f.principal * r) / (1 - Math.pow(1 + r, -f.duration_months));
  return round2(base + (f.insurance_monthly || 0));
});

const years = computed(() => {
  const map = new Map();
  for (const r of installments.value) {
    const y = Number(r.due_date.slice(0, 4));
    if (!map.has(y)) map.set(y, { year: y, rows: [], payment: 0, principal: 0, interest: 0, insurance: 0 });
    const g = map.get(y);
    g.rows.push(r);
    for (const k of ['payment', 'principal', 'interest', 'insurance']) g[k] = round2(g[k] + r[k]);
  }
  return [...map.values()];
});

const totals = computed(() => {
  const t = { payment: 0, principal: 0, interest: 0, insurance: 0 };
  for (const r of installments.value) for (const k of Object.keys(t)) t[k] += r[k];
  return t;
});

const remainingChart = computed(() => ({
  labels: installments.value.map((r) => date(r.due_date)),
  datasets: [
    {
      label: 'Capital restant dû',
      data: installments.value.map((r) => r.remaining),
      borderColor: '#2f5d8f',
      backgroundColor: 'rgba(47, 93, 143, 0.12)',
      fill: true,
      pointRadius: 0,
      tension: 0.2,
    },
  ],
}));

const yearlyChart = computed(() => ({
  labels: years.value.map((y) => y.year),
  datasets: [
    { label: 'Capital', data: years.value.map((y) => y.principal), backgroundColor: '#2f5d8f', stack: 's' },
    { label: 'Intérêts', data: years.value.map((y) => y.interest), backgroundColor: '#f59e0b', stack: 's' },
    { label: 'Assurance', data: years.value.map((y) => y.insurance), backgroundColor: '#94a3b8', stack: 's' },
  ],
}));

const tooltipEur = { callbacks: { label: (ctx) => `${ctx.dataset.label} : ${eur(ctx.parsed.y)}` } };
const lineOptions = {
  responsive: true,
  maintainAspectRatio: false,
  interaction: { mode: 'index', intersect: false },
  plugins: { legend: { display: false }, tooltip: tooltipEur },
  scales: { x: { ticks: { maxTicksLimit: 10 } }, y: { ticks: { callback: (v) => eur0(v) } } },
};
const barOptions = {
  responsive: true,
  maintainAspectRatio: false,
  interaction: { mode: 'index', intersect: false },
  plugins: { tooltip: tooltipEur },
  scales: { x: { stacked: true }, y: { stacked: true, ticks: { callback: (v) => eur0(v) } } },
};

async function load() {
  await attempt(async () => {
    loans.value = await api.get(`/loans?property_id=${store.propertyId}`);
    if (!loans.value.some((l) => l.id === selectedId.value)) selectedId.value = loans.value[0]?.id ?? null;
    await loadInstallments();
  });
}

async function loadInstallments() {
  installments.value = selectedId.value ? await api.get(`/loans/${selectedId.value}/installments`) : [];
  expanded.clear();
  const current = new Date().getFullYear();
  if (years.value.some((y) => y.year === current)) expanded.add(current);
}

async function select(id) {
  selectedId.value = id;
  await attempt(loadInstallments);
}

function toggle(y) {
  if (expanded.has(y)) expanded.delete(y);
  else expanded.add(y);
}

function expandAll() {
  if (expanded.size) expanded.clear();
  else years.value.forEach((y) => expanded.add(y.year));
}

function openForm(l) {
  form.value = l
    ? { ...l, regenerate: false }
    : { name: 'Prêt immobilier', bank: '', principal: '', annual_rate: '', duration_months: 240, start_date: todayIso(), insurance_monthly: 0, notes: '' };
}

async function save() {
  const data = { ...form.value, property_id: store.propertyId };
  let saved;
  const ok = await attempt(async () => {
    saved = data.id ? await api.put(`/loans/${data.id}`, data) : await api.post('/loans', data);
    if (data.id && data.regenerate) await api.post(`/loans/${data.id}/generate`);
  }, 'Prêt enregistré');
  if (ok) {
    form.value = null;
    selectedId.value = saved.id;
    load();
  }
}

function pickCsv(l) {
  csvTarget.value = l;
  csvInput.value.value = '';
  csvInput.value.click();
}

async function importCsv(e) {
  const file = e.target.files[0];
  const loan = csvTarget.value;
  if (!file || !loan) return;
  if (!confirm(`Remplacer le tableau d'amortissement de « ${loan.name} » par le contenu de ${file.name} ?`)) return;
  await attempt(async () => {
    const csv = await readTextFile(file);
    const res = await api.post(`/loans/${loan.id}/import`, { csv });
    selectedId.value = loan.id;
    await load();
    return res;
  }, 'Tableau importé');
}

async function remove(l) {
  if (!confirm(`Supprimer le prêt « ${l.name} » et son tableau d'amortissement ?`)) return;
  if (await attempt(() => api.del(`/loans/${l.id}`), 'Prêt supprimé')) load();
}

onMounted(load);
</script>

<style scoped>
.progress {
  height: 8px;
  border-radius: 99px;
  background: #e2e8f0;
  overflow: hidden;
  margin-top: 1rem;
}
.progress div {
  height: 100%;
  background: linear-gradient(90deg, #2f5d8f, #16a34a);
}
</style>
