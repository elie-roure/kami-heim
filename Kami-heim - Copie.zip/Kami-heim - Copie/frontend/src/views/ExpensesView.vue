<template>
  <div>
    <div class="page-header">
      <div>
        <h1>Charges & dépenses</h1>
        <div class="subtitle">{{ currentProperty?.name }} — appels de fonds du syndic, taxes, assurance, travaux…</div>
      </div>
      <div class="toolbar">
        <YearSelect v-model="year" />
        <select v-model="category">
          <option value="">Toutes les catégories</option>
          <option v-for="(label, key) in categories" :key="key" :value="key">{{ label }}</option>
        </select>
        <button class="btn" @click="openNew()">＋ Nouvelle dépense</button>
      </div>
    </div>

    <div class="kpis">
      <div class="kpi negative">
        <div class="label">Total payé {{ year }}</div>
        <div class="value">{{ eur(total) }}</div>
      </div>
      <div class="kpi positive">
        <div class="label">Dont récupérable</div>
        <div class="value">{{ eur(recoverable) }}</div>
        <div class="hint">refacturable au locataire</div>
      </div>
      <div class="kpi warning">
        <div class="label">Reste à votre charge</div>
        <div class="value">{{ eur(total - recoverable) }}</div>
      </div>
      <div class="kpi">
        <div class="label">Charges syndic {{ year }}</div>
        <div class="value">{{ eur(syndicTotal) }}</div>
      </div>
    </div>

      <div class="card">
        <h2>Par catégorie</h2>
        <div v-if="!byCategory.length" class="empty">—</div>
        <table v-else>
          <thead><tr><th>Catégorie</th><th class="num">Montant</th><th class="num">Récupérable</th></tr></thead>
          <tbody>
            <tr v-for="c in byCategory" :key="c.key" class="clickable" @click="category = category === c.key ? '' : c.key">
              <td>{{ categories[c.key] || c.key }}</td>
              <td class="num">{{ eur(c.amount) }}</td>
              <td class="num">{{ eur(c.recoverable) }}</td>
            </tr>
          </tbody>
          <tfoot>
            <tr><td>Total</td><td class="num">{{ eur(sumBy('amount')) }}</td><td class="num">{{ eur(sumBy('recoverable')) }}</td></tr>
          </tfoot>
        </table>
        <div class="notice" style="margin-top: 1rem">
          💡 La <strong>part récupérable</strong> (eau, entretien des parties communes, ascenseur, TEOM…) est indiquée sur le décompte annuel
          du syndic. Elle sert au calcul de la <router-link to="/regularisation">régularisation des charges</router-link>.
        </div>
      </div>

      <div class="card">
        <h2>Détail des dépenses</h2>
        <div v-if="!filtered.length" class="empty">Aucune dépense pour {{ year }}</div>
        <div v-else class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Date</th>
                <th>Catégorie</th>
                <th>Libellé</th>
                <th class="num">Montant</th>
                <th class="num">Récupérable</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="e in filtered" :key="e.id">
                <td>{{ date(e.date) }}</td>
                <td><span class="badge info">{{ categories[e.category] || e.category }}</span></td>
                <td>{{ e.label || '—' }}<div v-if="e.notes" class="help">{{ e.notes }}</div></td>
                <td class="num">{{ eur(e.amount) }}</td>
                <td class="num">{{ e.recoverable_amount ? eur(e.recoverable_amount) : '—' }}</td>
                <td class="actions">
                  <button class="btn ghost sm" @click="openEdit(e)">Modifier</button>
                  <button class="btn ghost sm" title="Dupliquer" @click="duplicate(e)">⧉</button>
                  <button class="btn ghost danger sm" @click="remove(e)">✕</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

    <Modal v-if="form" :title="form.id ? 'Modifier la dépense' : 'Nouvelle dépense'" @close="form = null">
      <form id="expense-form" class="form-grid" @submit.prevent="save">
        <label class="field">
          <span>Catégorie</span>
          <select v-model="form.category">
            <option v-for="(label, key) in categories" :key="key" :value="key">{{ label }}</option>
          </select>
        </label>
        <label class="field"><span>Date *</span><input v-model="form.date" type="date" required /></label>
        <label class="field full"><span>Libellé</span><input v-model="form.label" :placeholder="placeholder" /></label>
        <label class="field">
          <span>Montant payé (€) *</span><input v-model.number="form.amount" type="number" step="0.01" required />
          <small>Montant négatif pour un remboursement / avoir</small>
        </label>
        <label class="field">
          <span>Dont récupérable sur le locataire (€)</span><input v-model.number="form.recoverable_amount" type="number" step="0.01" />
          <small>{{ hint }}</small>
        </label>
        <label class="field full"><span>Notes</span><input v-model="form.notes" /></label>
        <template v-if="!form.id">
          <label class="checkbox full"><input v-model="form.repeat" type="checkbox" /> Dépense récurrente (ex : appels de fonds trimestriels)</label>
          <template v-if="form.repeat">
            <label class="field"><span>Nombre d'occurrences</span><input v-model.number="form.count" type="number" min="1" max="120" /></label>
            <label class="field">
              <span>Tous les</span>
              <select v-model.number="form.interval_months">
                <option :value="1">mois</option>
                <option :value="3">trimestres</option>
                <option :value="6">semestres</option>
                <option :value="12">ans</option>
              </select>
            </label>
          </template>
        </template>
      </form>
      <template #footer>
        <button class="btn secondary" type="button" @click="form = null">Annuler</button>
        <button class="btn" type="submit" form="expense-form">Enregistrer</button>
      </template>
    </Modal>
  </div>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue';
import { api, qs } from '../api.js';
import Modal from '../components/Modal.vue';
import YearSelect from '../components/YearSelect.vue';
import { currentYear, date, eur, round2, todayIso } from '../format.js';
import { attempt, currentProperty, store } from '../store.js';

const year = ref(currentYear());
const category = ref('');
const expenses = ref([]);
const form = ref(null);

const categories = computed(() => store.meta.expense_categories);
const filtered = computed(() => expenses.value.filter((e) => !category.value || e.category === category.value));
const total = computed(() => round2(filtered.value.reduce((s, e) => s + e.amount, 0)));
const recoverable = computed(() => round2(filtered.value.reduce((s, e) => s + e.recoverable_amount, 0)));
const syndicTotal = computed(() => round2(expenses.value.filter((e) => e.category === 'copropriete').reduce((s, e) => s + e.amount, 0)));
const sumBy = (k) => round2(byCategory.value.reduce((s, c) => s + c[k], 0));

const byCategory = computed(() => {
  const map = {};
  for (const e of expenses.value) {
    map[e.category] ??= { key: e.category, amount: 0, recoverable: 0 };
    map[e.category].amount += e.amount;
    map[e.category].recoverable += e.recoverable_amount;
  }
  return Object.values(map).sort((a, b) => b.amount - a.amount);
});

const HINTS = {
  copropriete: 'Voir la part « charges locatives » du décompte du syndic',
  taxe_fonciere: 'Indiquez ici le montant de la TEOM figurant sur l’avis',
  teom: 'La TEOM est entièrement récupérable',
  taxe_habitation: 'Non récupérable (due par l’occupant au 1er janvier)',
  energie: 'Récupérable si vous la refacturez au locataire',
};
const PLACEHOLDERS = {
  copropriete: 'Appel de fonds T1, régularisation syndic…',
  taxe_fonciere: 'Taxe foncière',
  assurance_pno: 'Assurance PNO',
  travaux: 'Remplacement chauffe-eau…',
};
const hint = computed(() => HINTS[form.value?.category] || 'Laisser à 0 si non refacturable');
const placeholder = computed(() => PLACEHOLDERS[form.value?.category] || '');

async function load() {
  await attempt(async () => {
    expenses.value = await api.get(`/expenses${qs({ property_id: store.propertyId, year: year.value })}`);
  });
}

function openNew(base = {}) {
  form.value = {
    category: category.value || 'copropriete',
    date: todayIso(),
    label: '',
    amount: '',
    recoverable_amount: 0,
    notes: '',
    repeat: false,
    count: 4,
    interval_months: 3,
    ...base,
  };
}

const openEdit = (e) => (form.value = { ...e });
const duplicate = (e) => openNew({ category: e.category, label: e.label, amount: e.amount, recoverable_amount: e.recoverable_amount, notes: e.notes });

async function save() {
  const data = { ...form.value, property_id: store.propertyId };
  const ok = await attempt(() => {
    if (data.id) return api.put(`/expenses/${data.id}`, data);
    if (data.repeat) return api.post('/expenses/recurring', data);
    return api.post('/expenses', data);
  }, 'Dépense enregistrée');
  if (ok) {
    form.value = null;
    const y = Number(data.date.slice(0, 4));
    if (y !== year.value) year.value = y;
    else load();
  }
}

async function remove(e) {
  if (!confirm('Supprimer cette dépense ?')) return;
  if (await attempt(() => api.del(`/expenses/${e.id}`), 'Dépense supprimée')) load();
}

watch(year, load);
onMounted(load);
</script>
