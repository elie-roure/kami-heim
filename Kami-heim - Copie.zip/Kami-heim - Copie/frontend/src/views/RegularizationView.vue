<template>
  <div>
    <div class="page-header">
      <div>
        <h1>Régularisation des charges</h1>
        <div class="subtitle">{{ currentProperty?.name }} — comparaison annuelle des provisions versées et des charges réelles récupérables</div>
      </div>
      <button class="btn" @click="startNew">＋ Nouvelle régularisation</button>
    </div>

    <div class="card">
      <div v-if="!list.length" class="empty">
        <div class="big">⚖️</div>
        Aucune régularisation enregistrée.<br />
        <span class="help">Saisissez d'abord vos charges avec leur part récupérable dans « Charges & syndic ».</span>
      </div>
      <div v-else class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Année</th>
              <th>Locataire</th>
              <th>Période</th>
              <th class="num">Provisions versées</th>
              <th class="num">Charges réelles</th>
              <th class="num">Solde</th>
              <th>Statut</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="r in list" :key="r.id">
              <td><strong>{{ r.year }}</strong></td>
              <td>{{ tenantName(r) }}</td>
              <td>{{ date(r.period_start) }} → {{ date(r.period_end) }}</td>
              <td class="num">{{ eur(r.provisions) }}</td>
              <td class="num">{{ eur(r.actual_charges) }}</td>
              <td class="num">
                <strong :class="r.balance > 0 ? 'text-danger' : 'text-success'">{{ eur(Math.abs(r.balance)) }}</strong>
                <div class="help">{{ r.balance > 0 ? 'à réclamer' : r.balance < 0 ? 'à rembourser' : 'soldé' }}</div>
              </td>
              <td><span class="badge" :class="STATUS_CLASS[r.status]">{{ r.status }}</span></td>
              <td class="actions">
                <a class="btn ghost sm" :href="`/api/regularizations/${r.id}/pdf`" target="_blank">📄 PDF</a>
                <button class="btn ghost sm" @click="openExisting(r)">Modifier</button>
                <button class="btn ghost danger sm" @click="remove(r)">✕</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <Modal v-if="picker" title="Nouvelle régularisation" @close="picker = null">
      <form id="picker-form" class="form-grid" @submit.prevent="compute">
        <label class="field">
          <span>Locataire</span>
          <select v-model="picker.tenant_id" required>
            <option v-for="t in tenants" :key="t.id" :value="t.id">{{ tenantName(t) }}</option>
          </select>
        </label>
        <label class="field"><span>Année</span><YearSelect v-model="picker.year" :future="0" /></label>
      </form>
      <p class="help">
        Le calcul reprend les provisions pour charges des loyers saisis et les parts récupérables des dépenses de l'année,
        au prorata de la durée d'occupation. Vous pourrez ajuster chaque ligne.
      </p>
      <template #footer>
        <button class="btn secondary" type="button" @click="picker = null">Annuler</button>
        <button class="btn" type="submit" form="picker-form">Calculer</button>
      </template>
    </Modal>

    <Modal v-if="editor" wide :title="`Régularisation ${editor.year} — ${editorTenantName}`" @close="editor = null">
      <div class="form-grid">
        <label class="field"><span>Début de période</span><input v-model="editor.period_start" type="date" /></label>
        <label class="field"><span>Fin de période</span><input v-model="editor.period_end" type="date" /></label>
        <div class="field">
          <span>Prorata d'occupation</span>
          <div style="padding-top: 0.5rem">{{ editor.occupancy_days }} / {{ editor.year_days }} jours ({{ pct(round2(ratio * 100)) }})</div>
        </div>
      </div>

      <h3 style="margin-top: 1.2rem">Charges récupérables</h3>
      <table>
        <thead>
          <tr><th>Nature de la charge</th><th class="num">Montant annuel</th><th class="num">Quote-part locataire</th><th></th></tr>
        </thead>
        <tbody>
          <tr v-for="(l, i) in editor.lines" :key="i">
            <td><input v-model="l.label" class="input-sm" style="width: 100%" /></td>
            <td class="num"><input v-model.number="l.total" class="input-sm" type="number" step="0.01" style="width: 120px" @input="l.share = round2((l.total || 0) * ratio)" /></td>
            <td class="num"><input v-model.number="l.share" class="input-sm" type="number" step="0.01" style="width: 120px" /></td>
            <td class="actions"><button class="btn ghost danger sm" type="button" @click="editor.lines.splice(i, 1)">✕</button></td>
          </tr>
          <tr v-if="!editor.lines.length"><td colspan="4" class="empty">Aucune charge récupérable trouvée pour cette année.</td></tr>
        </tbody>
        <tfoot>
          <tr>
            <td><button class="btn ghost sm" type="button" @click="editor.lines.push({ label: '', total: 0, share: 0 })">＋ Ajouter une ligne</button></td>
            <td class="num">Total</td>
            <td class="num">{{ eur(actual) }}</td>
            <td></td>
          </tr>
        </tfoot>
      </table>

      <div class="grid grid-2" style="margin-top: 1.2rem">
        <div>
          <label class="field">
            <span>Provisions pour charges versées (€)</span>
            <input v-model.number="editor.provisions" type="number" step="0.01" />
            <small>Somme des provisions des loyers saisis pour {{ editor.year }}</small>
          </label>
          <div class="kpi" :class="balance > 0 ? 'negative' : 'positive'" style="margin-top: 1rem">
            <div class="label">{{ balance > 0 ? 'Le locataire vous doit' : balance < 0 ? 'Vous devez rembourser' : 'Solde' }}</div>
            <div class="value">{{ eur(Math.abs(balance)) }}</div>
            <div class="hint">{{ eur(actual) }} de charges réelles − {{ eur(editor.provisions || 0) }} de provisions</div>
          </div>
        </div>
        <div class="form-grid" style="align-content: start">
          <label class="field">
            <span>Nouvelle provision mensuelle (€)</span>
            <input v-model="editor.new_provision" type="number" step="0.01" />
            <small>Actuelle : {{ eur(editor.current_provision) }}</small>
          </label>
          <label class="field">
            <span>Statut</span>
            <select v-model="editor.status">
              <option v-for="s in STATUSES" :key="s">{{ s }}</option>
            </select>
          </label>
          <label class="checkbox full"><input v-model="editor.apply_new_provision" type="checkbox" /> Appliquer la nouvelle provision au locataire</label>
          <label class="field full"><span>Message (apparaît sur le décompte)</span><textarea v-model="editor.notes"></textarea></label>
        </div>
      </div>

      <template #footer>
        <button class="btn secondary" type="button" @click="editor = null">Annuler</button>
        <button class="btn" type="button" @click="save">Enregistrer</button>
      </template>
    </Modal>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue';
import { api } from '../api.js';
import Modal from '../components/Modal.vue';
import YearSelect from '../components/YearSelect.vue';
import { currentYear, date, eur, pct, round2, tenantName } from '../format.js';
import { attempt, currentProperty, store } from '../store.js';

const STATUSES = ['brouillon', 'envoyée', 'réglée'];
const STATUS_CLASS = { brouillon: '', envoyée: 'info', réglée: 'success' };

const list = ref([]);
const tenants = ref([]);
const picker = ref(null);
const editor = ref(null);

const ratio = computed(() => (editor.value?.year_days ? editor.value.occupancy_days / editor.value.year_days : 1));
const actual = computed(() => round2((editor.value?.lines || []).reduce((s, l) => s + (Number(l.share) || 0), 0)));
const balance = computed(() => round2(actual.value - (Number(editor.value?.provisions) || 0)));
const editorTenantName = computed(() => tenantName(tenants.value.find((t) => t.id === editor.value?.tenant_id)));

async function load() {
  await attempt(async () => {
    [list.value, tenants.value] = await Promise.all([
      api.get(`/regularizations?property_id=${store.propertyId}`),
      api.get(`/tenants?property_id=${store.propertyId}`),
    ]);
  });
}

function startNew() {
  if (!tenants.value.length) return alert('Ajoutez d’abord un locataire.');
  picker.value = { tenant_id: tenants.value[0].id, year: currentYear() - 1 };
}

function toEditor(data, extra = {}) {
  editor.value = {
    ...data,
    lines: (data.details?.lines || []).map((l) => ({ ...l })),
    occupancy_days: data.details?.occupancy_days,
    year_days: data.details?.year_days,
    new_provision: data.new_provision ?? '',
    status: data.status || 'brouillon',
    notes: data.notes || '',
    apply_new_provision: false,
    current_provision: tenants.value.find((t) => t.id === data.tenant_id)?.charges_amount,
    ...extra,
  };
}

async function compute() {
  const { tenant_id, year } = picker.value;
  const existing = list.value.find((r) => r.tenant_id === tenant_id && r.year === year);
  if (existing) {
    picker.value = null;
    if (confirm(`Une régularisation ${year} existe déjà pour ce locataire. L'ouvrir ?`)) openExisting(existing);
    return;
  }
  await attempt(async () => {
    const preview = await api.get(`/regularizations/preview?tenant_id=${tenant_id}&year=${year}`);
    picker.value = null;
    toEditor(preview);
  });
}

function openExisting(r) {
  toEditor(r);
}

async function save() {
  const e = editor.value;
  const payload = {
    tenant_id: e.tenant_id,
    year: e.year,
    period_start: e.period_start,
    period_end: e.period_end,
    provisions: e.provisions,
    details: { lines: e.lines, occupancy_days: e.occupancy_days, year_days: e.year_days },
    new_provision: e.new_provision,
    apply_new_provision: e.apply_new_provision,
    status: e.status,
    notes: e.notes,
  };
  let saved;
  const ok = await attempt(async () => {
    saved = e.id ? await api.put(`/regularizations/${e.id}`, payload) : await api.post('/regularizations', payload);
  }, 'Régularisation enregistrée — le décompte PDF est disponible dans la liste');
  if (ok && saved) {
    editor.value = null;
    await load();
  }
}

async function remove(r) {
  if (!confirm(`Supprimer la régularisation ${r.year} de ${tenantName(r)} ?`)) return;
  if (await attempt(() => api.del(`/regularizations/${r.id}`), 'Régularisation supprimée')) load();
}

onMounted(load);
</script>
