<template>
  <div>
    <div class="page-header">
      <div>
        <h1>Tableau de bord</h1>
        <div class="subtitle">{{ scope === 'all' ? 'Tous les biens' : currentProperty?.name }} — ce que le bien vous rapporte et vous coûte{{ periodNote }}</div>
      </div>
      <div class="toolbar">
        <div class="segmented">
          <button :class="{ active: scope === 'property' }" @click="scope = 'property'">Ce bien</button>
          <button :class="{ active: scope === 'all' }" @click="scope = 'all'">Tous les biens</button>
        </div>
        <YearSelect v-model="year" />
      </div>
    </div>

    <template v-if="data">
      <div class="kpis">
        <div class="kpi positive">
          <div class="label">Loyers encaissés</div>
          <div class="value">{{ eur(t.revenue) }}</div>
          <div class="hint">dont {{ eur(t.charges) }} de provisions pour charges</div>
        </div>
        <div class="kpi negative">
          <div class="label">Charges & taxes payées</div>
          <div class="value">{{ eur(t.expenses) }}</div>
          <div class="hint">dont {{ eur(t.recoverable) }} récupérables</div>
        </div>
        <div class="kpi warning">
          <div class="label">Mensualités du prêt</div>
          <div class="value">{{ eur(t.loan) }}</div>
          <div class="hint">{{ eur(t.interest + t.insurance) }} d'intérêts & assurance · {{ eur(t.principal) }} de capital</div>
        </div>
        <div class="kpi" :class="t.cashflow >= 0 ? 'positive' : 'negative'">
          <div class="label">Cash-flow</div>
          <div class="value" :class="t.cashflow >= 0 ? 'text-success' : 'text-danger'">{{ eur(t.cashflow) }}</div>
          <div class="hint">soit {{ eur(t.cashflow / monthsCount) }} / mois (effort d'épargne si négatif)</div>
        </div>
        <div class="kpi" :class="t.result >= 0 ? 'positive' : 'negative'">
          <div class="label">Résultat (hors capital)</div>
          <div class="value" :class="t.result >= 0 ? 'text-success' : 'text-danger'">{{ eur(t.result) }}</div>
          <div class="hint">le capital remboursé constitue votre patrimoine</div>
        </div>
        <div class="kpi">
          <div class="label">Rendement brut / net</div>
          <div class="value">{{ pct(data.gross_yield) }}</div>
          <div class="hint">net {{ year }} : {{ pct(data.net_yield) }} · prix de revient {{ eur0(data.purchase_cost) }}</div>
        </div>
        <div class="kpi">
          <div class="label">Capital restant dû</div>
          <div class="value">{{ eur(data.loan_remaining) }}</div>
          <div class="hint">{{ data.active_tenants }} locataire(s) en place · {{ eur(data.expected_annual_rent) }} de loyers HC / an</div>
        </div>
        <div class="kpi" :class="data.unpaid.length ? 'negative' : 'positive'">
          <div class="label">Impayés {{ year }}</div>
          <div class="value">{{ eur(unpaidTotal) }}</div>
          <div class="hint">{{ data.unpaid.length }} échéance(s) non soldée(s)</div>
        </div>
      </div>

      <div class="card">
        <h2>Entrées et sorties mensuelles {{ year }}</h2>
        <div class="chart-box"><Bar :data="monthlyChart" :options="stackedOptions" /></div>
      </div>

      <div class="grid grid-2">
        <div class="card">
          <h2>Ce que coûte le bien en {{ year }}</h2>
          <div v-if="!costChart.labels.length" class="empty">Aucune dépense</div>
          <div v-else class="chart-box"><Doughnut :data="costChart" :options="doughnutOptions" /></div>
        </div>
        <div class="card">
          <h2>Bilan {{ year }}</h2>
          <table>
            <tbody>
              <tr><td>Loyers hors charges</td><td class="num text-success">+ {{ eur(t.rent) }}</td></tr>
              <tr><td>Provisions pour charges</td><td class="num text-success">+ {{ eur(t.charges) }}</td></tr>
              <tr v-for="c in data.by_category" :key="c.category">
                <td>{{ c.label }}</td>
                <td class="num text-danger">− {{ eur(c.amount) }}</td>
              </tr>
              <tr><td>Intérêts d'emprunt</td><td class="num text-danger">− {{ eur(t.interest) }}</td></tr>
              <tr><td>Assurance emprunteur</td><td class="num text-danger">− {{ eur(t.insurance) }}</td></tr>
            </tbody>
            <tfoot>
              <tr><td>Résultat</td><td class="num">{{ eur(t.result) }}</td></tr>
              <tr><td>Capital remboursé</td><td class="num">− {{ eur(t.principal) }}</td></tr>
              <tr><td>Cash-flow</td><td class="num" :class="t.cashflow >= 0 ? 'text-success' : 'text-danger'">{{ eur(t.cashflow) }}</td></tr>
            </tfoot>
          </table>
        </div>
      </div>

      <div class="grid grid-2">
        <div class="card">
          <h2>Évolution annuelle</h2>
          <div class="chart-box"><Bar :data="historyChart" :options="historyOptions" /></div>
        </div>
        <div class="card">
          <div class="card-header">
            <h2>Loyers impayés ou partiels</h2>
            <router-link class="btn ghost sm" to="/loyers">Gérer les loyers →</router-link>
          </div>
          <div v-if="!data.unpaid.length" class="empty">✅ Aucun impayé sur {{ year }}</div>
          <div v-else class="table-wrap" style="max-height: 320px; overflow-y: auto">
            <table>
              <thead><tr><th>Période</th><th>Locataire</th><th class="num">Attendu</th><th class="num">Reçu</th><th class="num">Manque</th></tr></thead>
              <tbody>
                <tr v-for="u in data.unpaid" :key="`${u.tenant_id}-${u.period}`">
                  <td>{{ periodLabel(u.period) }}</td>
                  <td>{{ u.tenant_name }}<div v-if="scope === 'all'" class="help">{{ u.property_name }}</div></td>
                  <td class="num">{{ eur(u.expected) }}</td>
                  <td class="num">{{ eur(u.paid) }}</td>
                  <td class="num text-danger"><strong>{{ eur(u.missing) }}</strong></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </template>
    <div v-else class="empty">Chargement…</div>
  </div>
</template>

<script setup>
import { Bar, Doughnut } from 'vue-chartjs';
import { computed, onMounted, ref, watch } from 'vue';
import { api, qs } from '../api.js';
import YearSelect from '../components/YearSelect.vue';
import { currentYear, eur, eur0, MONTHS, pct, periodLabel, round2 } from '../format.js';
import { attempt, currentProperty, store } from '../store.js';

const year = ref(currentYear());
const scope = ref(localStorage.getItem('kamiheim.dashboardScope') || 'property');
const data = ref(null);

const t = computed(() => data.value.totals);
const unpaidTotal = computed(() => round2(data.value.unpaid.reduce((s, u) => s + u.missing, 0)));
const monthsCount = computed(() => data.value.months_counted || 12);
const periodNote = computed(() => {
  if (!data.value || data.value.months_counted >= 12) return '';
  const month = new Date(year.value, data.value.months_counted - 1, 1).toLocaleDateString('fr-FR', { month: 'long' });
  return ` · chiffres cumulés de janvier à ${month}`;
});

const COLORS = ['#2f5d8f', '#f59e0b', '#dc2626', '#16a34a', '#8b5cf6', '#0ea5e9', '#ec4899', '#14b8a6', '#a16207', '#64748b', '#f97316', '#22c55e', '#6366f1'];

const monthlyChart = computed(() => {
  const m = data.value.months;
  return {
    labels: MONTHS,
    datasets: [
      { type: 'line', label: 'Cash-flow', data: m.map((x) => round2(x.rent + x.charges - x.expenses - x.interest - x.insurance - x.principal)), borderColor: '#1e293b', backgroundColor: '#1e293b', tension: 0.25, order: 0 },
      { label: 'Loyers HC', data: m.map((x) => x.rent), backgroundColor: '#16a34a', stack: 'in', order: 1 },
      { label: 'Provisions charges', data: m.map((x) => x.charges), backgroundColor: '#86efac', stack: 'in', order: 1 },
      { label: 'Charges & taxes', data: m.map((x) => x.expenses), backgroundColor: '#dc2626', stack: 'out', order: 1 },
      { label: 'Intérêts + assurance', data: m.map((x) => round2(x.interest + x.insurance)), backgroundColor: '#f59e0b', stack: 'out', order: 1 },
      { label: 'Capital remboursé', data: m.map((x) => x.principal), backgroundColor: '#94a3b8', stack: 'out', order: 1 },
    ],
  };
});

const costChart = computed(() => {
  const items = data.value.by_category.filter((c) => c.amount > 0).map((c) => ({ label: c.label, value: c.amount }));
  if (t.value.interest > 0) items.push({ label: "Intérêts d'emprunt", value: t.value.interest });
  if (t.value.insurance > 0) items.push({ label: 'Assurance emprunteur', value: t.value.insurance });
  return {
    labels: items.map((i) => i.label),
    datasets: [{ data: items.map((i) => i.value), backgroundColor: items.map((_, i) => COLORS[i % COLORS.length]) }],
  };
});

const historyChart = computed(() => {
  const h = data.value.history;
  return {
    labels: h.map((x) => x.year),
    datasets: [
      { type: 'line', label: 'Cash-flow', data: h.map((x) => x.cashflow), borderColor: '#1e293b', backgroundColor: '#1e293b', tension: 0.25, order: 0 },
      { label: 'Loyers encaissés', data: h.map((x) => x.revenue), backgroundColor: '#16a34a', order: 1 },
      { label: 'Charges & taxes', data: h.map((x) => x.expenses), backgroundColor: '#dc2626', order: 1 },
      { label: 'Intérêts + assurance', data: h.map((x) => x.loan_cost), backgroundColor: '#f59e0b', order: 1 },
      { label: 'Capital remboursé', data: h.map((x) => x.principal), backgroundColor: '#94a3b8', order: 1 },
    ],
  };
});

const tooltipEur = { callbacks: { label: (ctx) => `${ctx.dataset.label || ctx.label} : ${eur(ctx.parsed.y ?? ctx.parsed)}` } };
const eurAxis = { ticks: { callback: (v) => eur0(v) } };

const stackedOptions = {
  responsive: true,
  maintainAspectRatio: false,
  interaction: { mode: 'index', intersect: false },
  plugins: { tooltip: tooltipEur, legend: { position: 'bottom' } },
  scales: { x: { stacked: true }, y: { stacked: true, ...eurAxis } },
};
const historyOptions = {
  responsive: true,
  maintainAspectRatio: false,
  interaction: { mode: 'index', intersect: false },
  plugins: { tooltip: tooltipEur, legend: { position: 'bottom' } },
  scales: { y: eurAxis },
};
const doughnutOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { position: 'right' },
    tooltip: { callbacks: { label: (ctx) => `${ctx.label} : ${eur(ctx.parsed)}` } },
  },
};

async function load() {
  await attempt(async () => {
    data.value = await api.get(`/dashboard${qs({ year: year.value, property_id: scope.value === 'all' ? '' : store.propertyId })}`);
  });
}

watch(scope, (v) => {
  localStorage.setItem('kamiheim.dashboardScope', v);
  load();
});
watch(year, load);
onMounted(load);
</script>
