<template>
  <div v-if="tenant">
    <div class="page-header">
      <div>
        <router-link to="/locataires" class="help">← Locataires</router-link>
        <h1>{{ tenantName(tenant) }}</h1>
        <div class="subtitle">
          <span class="badge" :class="leaseStatus(tenant) === 'active' ? 'success' : ''">{{ LEASE_STATUS_LABELS[leaseStatus(tenant)] }}</span>
          · {{ propertyName }}
        </div>
      </div>
      <button class="btn secondary" @click="editing = true">Modifier</button>
    </div>

    <div class="grid grid-2">
      <div class="card">
        <h2>Informations</h2>
        <dl class="dl">
          <dt>E-mail</dt><dd>{{ tenant.email || '—' }}</dd>
          <dt>Téléphone</dt><dd>{{ tenant.phone || '—' }}</dd>
          <dt>Bail</dt><dd>du {{ date(tenant.lease_start) }} {{ tenant.lease_end ? `au ${date(tenant.lease_end)}` : '(en cours)' }}</dd>
          <dt>Loyer hors charges</dt><dd>{{ eur(tenant.rent_amount) }}</dd>
          <dt>Provision pour charges</dt><dd>{{ eur(tenant.charges_amount) }}</dd>
          <dt>Total mensuel</dt><dd><strong>{{ eur(tenant.rent_amount + tenant.charges_amount) }}</strong></dd>
          <dt>Dépôt de garantie</dt><dd>{{ eur(tenant.deposit) }}</dd>
          <dt>Paiement le</dt><dd>{{ tenant.payment_day || 1 }} du mois</dd>
        </dl>
        <p v-if="tenant.notes" class="help" style="white-space: pre-line">{{ tenant.notes }}</p>
      </div>

      <div class="card">
        <div class="card-header">
          <h2>Derniers paiements</h2>
          <router-link class="btn ghost sm" to="/loyers">Gérer les loyers →</router-link>
        </div>
        <div v-if="!payments.length" class="empty">Aucun paiement enregistré</div>
        <div v-else class="table-wrap" style="max-height: 320px; overflow-y: auto">
          <table>
            <thead><tr><th>Période</th><th class="num">Dû</th><th class="num">Payé</th><th></th></tr></thead>
            <tbody>
              <tr v-for="p in payments" :key="p.id">
                <td>{{ periodLabel(p.period) }}</td>
                <td class="num">{{ eur(p.rent_amount + p.charges_amount) }}</td>
                <td class="num" :class="p.paid_amount < p.rent_amount + p.charges_amount - 0.005 ? 'text-danger' : 'text-success'">{{ eur(p.paid_amount) }}</td>
                <td class="actions"><a class="btn ghost sm" :href="`/api/rents/${p.id}/receipt.pdf`" target="_blank">📄 {{ p.paid_amount < p.rent_amount + p.charges_amount - 0.005 ? 'Reçu' : 'Quittance' }}</a></td>
              </tr>
            </tbody>
          </table>
        </div>
        <div v-if="regularizations.length" style="margin-top: 1rem">
          <h3>Régularisations de charges</h3>
          <div v-for="r in regularizations" :key="r.id" class="help">
            {{ r.year }} : solde
            <strong :class="r.balance > 0 ? 'text-danger' : 'text-success'">{{ eur(r.balance) }}</strong>
            · <a :href="`/api/regularizations/${r.id}/pdf`" target="_blank">PDF</a>
          </div>
        </div>
      </div>
    </div>

    <DocumentList :property-id="tenant.property_id" :tenant-id="tenant.id" default-category="bail" />

    <TenantForm v-if="editing" :tenant="tenant" @close="editing = false" @saved="onSaved" />
  </div>
  <div v-else-if="loaded" class="card empty">Locataire introuvable. <router-link to="/locataires">Retour</router-link></div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue';
import { useRoute } from 'vue-router';
import { api } from '../api.js';
import DocumentList from '../components/DocumentList.vue';
import TenantForm from '../components/TenantForm.vue';
import { date, eur, LEASE_STATUS_LABELS, leaseStatus, periodLabel, tenantName } from '../format.js';
import { store } from '../store.js';

const route = useRoute();
const tenant = ref(null);
const payments = ref([]);
const regularizations = ref([]);
const loaded = ref(false);
const editing = ref(false);

const propertyName = computed(() => store.properties.find((p) => p.id === tenant.value?.property_id)?.name || '');

async function load() {
  try {
    const id = route.params.id;
    tenant.value = await api.get(`/tenants/${id}`);
    [payments.value, regularizations.value] = await Promise.all([
      api.get(`/rents?tenant_id=${id}`),
      api.get(`/regularizations?tenant_id=${id}`),
    ]);
  } catch {
    tenant.value = null;
  } finally {
    loaded.value = true;
  }
}

function onSaved(saved) {
  tenant.value = saved;
  editing.value = false;
}

onMounted(load);
</script>
