<template>
  <div>
    <div class="page-header">
      <div>
        <h1>Mes biens</h1>
        <div class="subtitle">Appartements, maisons ou locaux que vous mettez en location</div>
      </div>
      <button class="btn" @click="edit(null)">＋ Nouveau bien</button>
    </div>

    <div v-if="!store.properties.length" class="card empty">
      <div class="big">🏠</div>
      Aucun bien pour le moment.
    </div>

    <div class="grid grid-3">
      <div v-for="p in store.properties" :key="p.id" class="card">
        <div class="card-header">
          <h2>{{ p.name }}</h2>
          <span v-if="p.id === store.propertyId" class="badge success">Sélectionné</span>
          <button v-else class="btn ghost sm" @click="setProperty(p.id)">Sélectionner</button>
        </div>
        <dl class="dl">
          <dt>Adresse</dt>
          <dd>{{ [p.address, p.postal_code, p.city].filter(Boolean).join(', ') || '—' }}</dd>
          <dt>Type</dt>
          <dd>{{ p.type || '—' }}<template v-if="p.surface"> · {{ p.surface }} m²</template><template v-if="p.rooms"> · {{ p.rooms }} pièce(s)</template></dd>
          <dt>Prix d'achat</dt>
          <dd>{{ eur(p.purchase_price) }}<span v-if="p.notary_fees" class="text-muted"> + {{ eur(p.notary_fees) }} de frais</span></dd>
          <dt>Acquis le</dt>
          <dd>{{ date(p.purchase_date) }}</dd>
        </dl>
        <p v-if="p.notes" class="help">{{ p.notes }}</p>
        <div class="toolbar" style="margin-top: 1rem">
          <button class="btn secondary sm" @click="edit(p)">Modifier</button>
          <button class="btn ghost danger sm" @click="remove(p)">Supprimer</button>
        </div>
      </div>
    </div>

    <Modal v-if="form" :title="form.id ? 'Modifier le bien' : 'Nouveau bien'" @close="form = null">
      <form id="property-form" class="form-grid" @submit.prevent="save">
        <label class="field full"><span>Nom du bien *</span><input v-model="form.name" required placeholder="Appartement T2 centre-ville" /></label>
        <label class="field full"><span>Adresse</span><input v-model="form.address" /></label>
        <label class="field"><span>Code postal</span><input v-model="form.postal_code" /></label>
        <label class="field"><span>Ville</span><input v-model="form.city" /></label>
        <label class="field">
          <span>Type</span>
          <select v-model="form.type">
            <option value="">—</option>
            <option>Appartement</option>
            <option>Maison</option>
            <option>Studio</option>
            <option>Local commercial</option>
            <option>Parking / box</option>
            <option>Autre</option>
          </select>
        </label>
        <label class="field"><span>Surface (m²)</span><input v-model="form.surface" type="number" step="0.01" min="0" /></label>
        <label class="field"><span>Nombre de pièces</span><input v-model="form.rooms" type="number" min="0" /></label>
        <label class="field"><span>Date d'acquisition</span><input v-model="form.purchase_date" type="date" /></label>
        <label class="field"><span>Prix d'achat (€)</span><input v-model="form.purchase_price" type="number" step="0.01" min="0" /></label>
        <label class="field"><span>Frais de notaire / agence (€)</span><input v-model="form.notary_fees" type="number" step="0.01" min="0" /></label>
        <label class="field full"><span>Notes</span><textarea v-model="form.notes" placeholder="Lot de copropriété, syndic, n° fiscal…"></textarea></label>
      </form>
      <template #footer>
        <button class="btn secondary" type="button" @click="form = null">Annuler</button>
        <button class="btn" type="submit" form="property-form">Enregistrer</button>
      </template>
    </Modal>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { api } from '../api.js';
import Modal from '../components/Modal.vue';
import { date, eur } from '../format.js';
import { attempt, loadProperties, setProperty, store } from '../store.js';

const form = ref(null);

function edit(p) {
  form.value = p ? { ...p } : { name: '', type: 'Appartement' };
}

async function save() {
  const data = form.value;
  let saved;
  const ok = await attempt(async () => {
    saved = data.id ? await api.put(`/properties/${data.id}`, data) : await api.post('/properties', data);
    await loadProperties();
  }, 'Bien enregistré');
  if (ok) {
    if (!data.id) setProperty(saved.id);
    form.value = null;
  }
}

async function remove(p) {
  if (!confirm(`Supprimer « ${p.name} » ainsi que TOUTES ses données (locataires, loyers, charges, prêts, documents) ?`)) return;
  await attempt(async () => {
    await api.del(`/properties/${p.id}`);
    await loadProperties();
  }, 'Bien supprimé');
}
</script>
