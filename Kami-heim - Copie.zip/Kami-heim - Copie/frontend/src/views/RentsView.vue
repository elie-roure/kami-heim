<template>
  <div>
    <div class="page-header">
      <div>
        <h1>Loyers & quittances</h1>
        <div class="subtitle">{{ currentProperty?.name }} — cliquez sur un mois pour saisir ou modifier un paiement</div>
      </div>
      <div class="toolbar">
        <YearSelect v-model="year" />
        <button class="btn" @click="openNew()">＋ Saisir un paiement</button>
      </div>
    </div>

    <div class="card">
      <div class="card-header">
        <h2>Suivi {{ year }}</h2>
        <form class="toolbar" @submit.prevent="bulk">
          <input v-model="bulkPeriod" type="month" required />
          <button class="btn secondary sm" type="submit">✔ Marquer tous les loyers du mois comme payés</button>
        </form>
      </div>
      <div v-if="!yearTenants.length" class="empty">Aucun locataire sur cette année. <router-link to="/locataires">Ajouter un locataire</router-link></div>
      <div v-else class="table-wrap">
        <table class="rent-grid">
          <thead>
            <tr>
              <th>Locataire</th>
              <th v-for="(m, i) in MONTHS" :key="i">{{ m }}</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="t in yearTenants" :key="t.id">
              <td><router-link :to="`/locataires/${t.id}`">{{ tenantName(t) }}</router-link></td>
              <td v-for="m in 12" :key="m">
                <span class="cell" :class="cell(t, m).status" :title="cell(t, m).title" @click="onCell(t, m)">{{ cell(t, m).text }}</span>
              </td>
            </tr>
          </tbody>
        </table>
        <div class="legend">
          <span style="--c: #dcfce7">Payé</span>
          <span style="--c: #fef3c7">Paiement partiel</span>
          <span style="--c: #fee2e2">Impayé</span>
          <span style="--c: #f1f5f9">À venir</span>
        </div>
      </div>
    </div>

    <div class="card">
      <h2>Paiements {{ year }}</h2>
      <div v-if="!payments.length" class="empty">Aucun paiement saisi</div>
      <div v-else class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Période</th>
              <th>Locataire</th>
              <th class="num">Loyer</th>
              <th class="num">Charges</th>
              <th class="num">Payé</th>
              <th>Date</th>
              <th>Mode</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="p in payments" :key="p.id">
              <td>{{ periodLabel(p.period) }}</td>
              <td>{{ tenantName(p) }}</td>
              <td class="num">{{ eur(p.rent_amount) }}</td>
              <td class="num">{{ eur(p.charges_amount) }}</td>
              <td class="num">
                <span :class="isPartial(p) ? 'text-danger' : ''">{{ eur(p.paid_amount) }}</span>
                <span v-if="isPartial(p)" class="badge warning" style="margin-left: 0.3rem">partiel</span>
              </td>
              <td>{{ date(p.payment_date) }}</td>
              <td>{{ p.method || '—' }}</td>
              <td class="actions">
                <a class="btn ghost sm" :href="`/api/rents/${p.id}/receipt.pdf`" target="_blank">📄 {{ isPartial(p) ? 'Reçu' : 'Quittance' }}</a>
                <button class="btn ghost sm" @click="openEdit(p)">Modifier</button>
                <button class="btn ghost danger sm" @click="remove(p)">Supprimer</button>
              </td>
            </tr>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="2">Total</td>
              <td class="num">{{ eur(sum('rent_amount')) }}</td>
              <td class="num">{{ eur(sum('charges_amount')) }}</td>
              <td class="num">{{ eur(sum('paid_amount')) }}</td>
              <td colspan="3"></td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>

    <Modal v-if="form" :title="form.id ? 'Modifier le paiement' : 'Nouveau paiement'" @close="form = null">
      <form id="payment-form" class="form-grid" @submit.prevent="save">
        <label class="field">
          <span>Locataire *</span>
          <select v-model="form.tenant_id" required :disabled="!!form.id" @change="applyTenantDefaults">
            <option v-for="t in tenants" :key="t.id" :value="t.id">{{ tenantName(t) }}</option>
          </select>
        </label>
        <label class="field"><span>Période (mois) *</span><input v-model="form.period" type="month" required /></label>
        <label class="field"><span>Loyer hors charges (€)</span><input v-model.number="form.rent_amount" type="number" step="0.01" @input="syncPaid" /></label>
        <label class="field"><span>Provision pour charges (€)</span><input v-model.number="form.charges_amount" type="number" step="0.01" @input="syncPaid" /></label>
        <label class="field">
          <span>Montant reçu (€)</span><input v-model.number="form.paid_amount" type="number" step="0.01" @input="paidTouched = true" />
          <small>Total dû : {{ eur((form.rent_amount || 0) + (form.charges_amount || 0)) }}</small>
        </label>
        <label class="field"><span>Date du paiement</span><input v-model="form.payment_date" type="date" /></label>
        <label class="field">
          <span>Mode de paiement</span>
          <select v-model="form.method">
            <option value="">—</option>
            <option v-for="m in store.meta.payment_methods" :key="m">{{ m }}</option>
          </select>
        </label>
        <label class="field full"><span>Notes</span><input v-model="form.notes" /></label>
      </form>
      <template #footer>
        <a v-if="form.id" class="btn secondary" :href="`/api/rents/${form.id}/receipt.pdf`" target="_blank" style="margin-right: auto">📄 Quittance</a>
        <button class="btn secondary" type="button" @click="form = null">Annuler</button>
        <button class="btn" type="submit" form="payment-form">Enregistrer</button>
      </template>
    </Modal>
  </div>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue';
import { api, qs } from '../api.js';
import Modal from '../components/Modal.vue';
import YearSelect from '../components/YearSelect.vue';
import { currentPeriod, currentYear, date, eur, leaseCovers, MONTHS, periodLabel, round2, tenantName, todayIso } from '../format.js';
import { attempt, currentProperty, notify, store } from '../store.js';

const year = ref(currentYear());
const tenants = ref([]);
const payments = ref([]);
const form = ref(null);
const paidTouched = ref(false);
const bulkPeriod = ref(currentPeriod());

const pad = (n) => String(n).padStart(2, '0');
const isPartial = (p) => p.paid_amount < p.rent_amount + p.charges_amount - 0.005;
const sum = (k) => round2(payments.value.reduce((s, p) => s + p[k], 0));

const yearTenants = computed(() =>
  tenants.value.filter((t) => Array.from({ length: 12 }, (_, i) => `${year.value}-${pad(i + 1)}`).some((p) => leaseCovers(t, p))),
);

const paymentIndex = computed(() => new Map(payments.value.map((p) => [`${p.tenant_id}|${p.period}`, p])));

function cell(t, m) {
  const period = `${year.value}-${pad(m)}`;
  const p = paymentIndex.value.get(`${t.id}|${period}`);
  if (p) {
    const partial = isPartial(p);
    return {
      status: partial ? 'partial' : 'paid',
      text: partial ? `${Math.round(p.paid_amount)} €` : '✓',
      title: `${periodLabel(period)} : ${eur(p.paid_amount)} reçu${p.payment_date ? ` le ${date(p.payment_date)}` : ''}`,
      payment: p,
    };
  }
  if (!leaseCovers(t, period)) return { status: 'none', text: '·', title: 'Hors bail' };
  if (period <= currentPeriod()) return { status: 'unpaid', text: '✗', title: `${periodLabel(period)} : impayé` };
  return { status: 'future', text: '', title: `${periodLabel(period)} : à venir` };
}

function onCell(t, m) {
  const c = cell(t, m);
  if (c.payment) openEdit(c.payment);
  else if (c.status !== 'none') openNew(t, `${year.value}-${pad(m)}`);
}

async function load() {
  await attempt(async () => {
    [tenants.value, payments.value] = await Promise.all([
      api.get(`/tenants?property_id=${store.propertyId}`),
      api.get(`/rents${qs({ property_id: store.propertyId, year: year.value })}`),
    ]);
  });
}

function openNew(tenant, period) {
  const t = tenant || tenants.value.find((x) => leaseCovers(x, currentPeriod())) || tenants.value[0];
  if (!t) return alert('Ajoutez d’abord un locataire.');
  paidTouched.value = false;
  form.value = {
    tenant_id: t.id,
    period: period || currentPeriod(),
    payment_date: todayIso(),
    method: 'Virement',
    notes: '',
  };
  applyTenantDefaults();
}

function openEdit(p) {
  paidTouched.value = true;
  form.value = { ...p, method: p.method || '' };
}

function applyTenantDefaults() {
  if (form.value.id) return;
  const t = tenants.value.find((x) => x.id === form.value.tenant_id);
  if (!t) return;
  form.value.rent_amount = t.rent_amount;
  form.value.charges_amount = t.charges_amount;
  paidTouched.value = false;
  syncPaid();
}

function syncPaid() {
  if (!paidTouched.value) form.value.paid_amount = round2((form.value.rent_amount || 0) + (form.value.charges_amount || 0));
}

async function save() {
  const data = form.value;
  const ok = await attempt(
    () => (data.id ? api.put(`/rents/${data.id}`, data) : api.post('/rents', data)),
    'Paiement enregistré',
  );
  if (ok) {
    form.value = null;
    const y = Number(data.period.slice(0, 4));
    if (y !== year.value) year.value = y;
    else load();
  }
}

async function remove(p) {
  if (!confirm(`Supprimer le paiement de ${periodLabel(p.period)} ?`)) return;
  if (await attempt(() => api.del(`/rents/${p.id}`), 'Paiement supprimé')) load();
}

async function bulk() {
  if (!confirm(`Enregistrer le paiement complet de ${periodLabel(bulkPeriod.value)} pour tous les locataires sans paiement ?`)) return;
  await attempt(async () => {
    const res = await api.post('/rents/bulk', { property_id: store.propertyId, period: bulkPeriod.value, payment_date: todayIso(), method: 'Virement' });
    const y = Number(bulkPeriod.value.slice(0, 4));
    if (y !== year.value) year.value = y;
    else await load();
    notify(`${res.created} paiement(s) créé(s)`);
  });
}

watch(year, load);
onMounted(load);
</script>
