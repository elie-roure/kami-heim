<template>
  <div>
    <div class="page-header">
      <div>
        <h1>Paramètres</h1>
        <div class="subtitle">Informations du bailleur utilisées sur les quittances et décomptes de charges</div>
      </div>
    </div>

    <div class="grid grid-2">
      <form class="card" @submit.prevent="save">
        <h2>Bailleur</h2>
        <div class="form-grid">
          <label class="field full"><span>Nom et prénom (ou SCI)</span><input v-model="form.owner_name" /></label>
          <label class="field full"><span>Adresse</span><input v-model="form.owner_address" /></label>
          <label class="field"><span>Code postal</span><input v-model="form.owner_postal_code" /></label>
          <label class="field"><span>Ville</span><input v-model="form.owner_city" /><small>Utilisée pour « Fait à … »</small></label>
          <label class="field"><span>E-mail</span><input v-model="form.owner_email" type="email" /></label>
          <label class="field"><span>Téléphone</span><input v-model="form.owner_phone" /></label>
        </div>
        <div class="toolbar" style="margin-top: 1rem"><button class="btn" type="submit">Enregistrer</button></div>
      </form>

      <div>
        <div class="card">
          <h2>Signature</h2>
          <p class="help">Image PNG ou JPEG de votre signature, ajoutée automatiquement aux quittances et décomptes.</p>
          <div v-if="form.has_signature" style="margin-bottom: 1rem">
            <img :src="`/api/settings/signature?v=${signatureVersion}`" alt="Signature" style="max-height: 90px; max-width: 260px; border: 1px dashed #cbd5e1; padding: 6px; border-radius: 6px" />
          </div>
          <div class="toolbar">
            <label class="btn secondary">
              {{ form.has_signature ? 'Remplacer' : 'Ajouter une signature' }}
              <input type="file" accept="image/png,image/jpeg" style="display: none" @change="uploadSignature" />
            </label>
            <button v-if="form.has_signature" class="btn ghost danger" @click="removeSignature">Supprimer</button>
          </div>
        </div>

        <div class="card">
          <h2>Sauvegarde</h2>
          <p class="help">
            Toutes les données (base SQLite et documents) sont stockées dans le dossier <code>data/</code> monté par Docker.
            Téléchargez régulièrement une archive de sauvegarde. Pour restaurer, décompressez l'archive dans le dossier
            <code>data/</code> (application arrêtée).
          </p>
          <a class="btn" href="/api/backup">⬇ Télécharger une sauvegarde (.zip)</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, reactive, ref } from 'vue';
import { api } from '../api.js';
import { attempt } from '../store.js';

const form = reactive({ has_signature: false });
const signatureVersion = ref(Date.now());

async function load() {
  await attempt(async () => Object.assign(form, await api.get('/settings')));
}

async function save() {
  await attempt(async () => Object.assign(form, await api.put('/settings', form)), 'Paramètres enregistrés');
}

async function uploadSignature(e) {
  const file = e.target.files[0];
  if (!file) return;
  const data = new FormData();
  data.append('file', file);
  await attempt(async () => {
    Object.assign(form, await api.post('/settings/signature', data));
    signatureVersion.value = Date.now();
  }, 'Signature enregistrée');
  e.target.value = '';
}

async function removeSignature() {
  if (!confirm('Supprimer la signature ?')) return;
  await attempt(async () => Object.assign(form, await api.del('/settings/signature')), 'Signature supprimée');
}

onMounted(load);
</script>
