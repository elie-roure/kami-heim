import { createRouter, createWebHistory } from 'vue-router';
import DashboardView from './views/DashboardView.vue';

const routes = [
  { path: '/', name: 'dashboard', component: DashboardView, meta: { title: 'Tableau de bord' } },
  { path: '/biens', name: 'properties', component: () => import('./views/PropertiesView.vue'), meta: { title: 'Mes biens' } },
  { path: '/locataires', name: 'tenants', component: () => import('./views/TenantsView.vue'), meta: { title: 'Locataires' } },
  { path: '/locataires/:id', name: 'tenant', component: () => import('./views/TenantDetailView.vue'), meta: { title: 'Locataire' } },
  { path: '/loyers', name: 'rents', component: () => import('./views/RentsView.vue'), meta: { title: 'Loyers & quittances' } },
  { path: '/charges', name: 'expenses', component: () => import('./views/ExpensesView.vue'), meta: { title: 'Charges & dépenses' } },
  { path: '/regularisation', name: 'regularization', component: () => import('./views/RegularizationView.vue'), meta: { title: 'Régularisation des charges' } },
  { path: '/pret', name: 'loans', component: () => import('./views/LoansView.vue'), meta: { title: 'Prêt immobilier' } },
  { path: '/documents', name: 'documents', component: () => import('./views/DocumentsView.vue'), meta: { title: 'Documents' } },
  { path: '/parametres', name: 'settings', component: () => import('./views/SettingsView.vue'), meta: { title: 'Paramètres' } },
  { path: '/:pathMatch(.*)*', redirect: '/' },
];

const router = createRouter({ history: createWebHistory(), routes });

router.afterEach((to) => {
  document.title = `${to.meta.title || 'Kami-heim'} · Kami-heim`;
});

export default router;
