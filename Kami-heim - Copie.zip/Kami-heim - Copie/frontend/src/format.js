const eurFormatter = new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR' });
const eur0Formatter = new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 });

export const eur = (v) => (v === null || v === undefined || v === '' ? '—' : eurFormatter.format(Number(v)));
export const eur0 = (v) => eur0Formatter.format(Number(v) || 0);
export const pct = (v) => (v === null || v === undefined ? '—' : `${Number(v).toLocaleString('fr-FR', { maximumFractionDigits: 2 })} %`);

export function date(iso) {
  if (!iso) return '—';
  const [y, m, d] = iso.slice(0, 10).split('-');
  return `${d}/${m}/${y}`;
}

export const MONTHS = ['Janv.', 'Févr.', 'Mars', 'Avr.', 'Mai', 'Juin', 'Juil.', 'Août', 'Sept.', 'Oct.', 'Nov.', 'Déc.'];

export function periodLabel(period) {
  if (!period) return '';
  const [y, m] = period.split('-').map(Number);
  const label = new Date(y, m - 1, 1).toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
  return label.charAt(0).toUpperCase() + label.slice(1);
}

const pad = (n) => String(n).padStart(2, '0');
export function todayIso() {
  const d = new Date();
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
export const currentPeriod = () => todayIso().slice(0, 7);
export const currentYear = () => new Date().getFullYear();

export const tenantName = (t) => (t ? [t.first_name, t.last_name].filter(Boolean).join(' ') : '');

export function leaseStatus(t, onIso = todayIso()) {
  if (t.lease_start && t.lease_start > onIso) return 'upcoming';
  if (t.lease_end && t.lease_end < onIso) return 'ended';
  return 'active';
}

export const LEASE_STATUS_LABELS = { active: 'En cours', upcoming: 'À venir', ended: 'Terminé' };

/** True when the lease overlaps the given YYYY-MM period. */
export function leaseCovers(t, period) {
  const [y, m] = period.split('-').map(Number);
  const start = `${period}-01`;
  const end = `${period}-${pad(new Date(y, m, 0).getDate())}`;
  return (!t.lease_start || t.lease_start <= end) && (!t.lease_end || t.lease_end >= start);
}

export function fileSize(bytes) {
  if (!bytes) return '—';
  if (bytes < 1024) return `${bytes} o`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} Ko`;
  return `${(bytes / 1024 / 1024).toFixed(1)} Mo`;
}

export const round2 = (n) => Math.round((Number(n) + Number.EPSILON) * 100) / 100;

/** Decodes a text file trying UTF-8 first, then Windows-1252 (common for French bank exports). */
export async function readTextFile(file) {
  const buffer = await file.arrayBuffer();
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(buffer);
  } catch {
    return new TextDecoder('windows-1252').decode(buffer);
  }
}
