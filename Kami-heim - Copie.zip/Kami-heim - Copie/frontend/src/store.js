import { computed, reactive } from 'vue';
import { api } from './api.js';

export const store = reactive({
  loaded: false,
  properties: [],
  propertyId: Number(localStorage.getItem('kamiheim.propertyId')) || null,
  meta: { expense_categories: {}, document_categories: {}, payment_methods: [] },
  toasts: [],
});

export const currentProperty = computed(() => store.properties.find((p) => p.id === store.propertyId) || null);

export function setProperty(id) {
  store.propertyId = id || null;
  if (id) localStorage.setItem('kamiheim.propertyId', String(id));
  else localStorage.removeItem('kamiheim.propertyId');
}

export async function loadProperties() {
  store.properties = await api.get('/properties');
  if (!store.properties.some((p) => p.id === store.propertyId)) setProperty(store.properties[0]?.id ?? null);
}

export async function init() {
  try {
    const [meta] = await Promise.all([api.get('/meta'), loadProperties()]);
    store.meta = meta;
  } catch (err) {
    notify(err.message, 'error');
  } finally {
    store.loaded = true;
  }
}

let toastId = 0;
export function notify(message, type = 'success') {
  const id = ++toastId;
  store.toasts.push({ id, message, type });
  setTimeout(() => {
    store.toasts = store.toasts.filter((t) => t.id !== id);
  }, type === 'error' ? 6000 : 3500);
}

/** Runs an async action and shows its error as a toast; returns true on success. */
export async function attempt(fn, successMessage) {
  try {
    await fn();
    if (successMessage) notify(successMessage);
    return true;
  } catch (err) {
    notify(err.message, 'error');
    return false;
  }
}
