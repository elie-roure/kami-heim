<template>
  <Modal :title="tenant?.id ? 'Modifier le locataire' : 'Nouveau locataire'" @close="$emit('close')">
    <form id="tenant-form" class="form-grid" @submit.prevent="save">
      <label class="field"><span>Prénom(s)</span><input v-model="form.first_name" placeholder="Marie et Paul" /></label>
      <label class="field"><span>Nom *</span><input v-model="form.last_name" required /></label>
      <label class="field"><span>E-mail</span><input v-model="form.email" type="email" /></label>
      <label class="field"><span>Téléphone</span><input v-model="form.phone" /></label>
      <label class="field"><span>Début du bail</span><input v-model="form.lease_start" type="date" /></label>
      <label class="field">
        <span>Fin du bail</span><input v-model="form.lease_end" type="date" />
        <small>Laisser vide si le bail est en cours</small>
      </label>
      <label class="field"><span>Loyer hors charges (€)</span><input v-model="form.rent_amount" type="number" step="0.01" min="0" /></label>
      <label class="field"><span>Provision pour charges (€)</span><input v-model="form.charges_amount" type="number" step="0.01" min="0" /></label>
      <label class="field"><span>Dépôt de garantie (€)</span><input v-model="form.deposit" type="number" step="0.01" min="0" /></label>
      <label class="field"><span>Jour de paiement</span><input v-model="form.payment_day" type="number" min="1" max="31" /></label>
      <label class="field full"><span>Notes</span><textarea v-model="form.notes" placeholder="Garant, coordonnées bancaires, remarques…"></textarea></label>
    </form>
    <template #footer>
      <button class="btn secondary" type="button" @click="$emit('close')">Annuler</button>
      <button class="btn" type="submit" form="tenant-form" :disabled="saving">Enregistrer</button>
    </template>
  </Modal>
</template>

<script setup>
import { reactive, ref } from 'vue';
import { api } from '../api.js';
import { attempt, store } from '../store.js';
import Modal from './Modal.vue';

const props = defineProps({ tenant: { type: Object, default: null } });
const emit = defineEmits(['close', 'saved']);

const form = reactive({
  first_name: '',
  last_name: '',
  email: '',
  phone: '',
  lease_start: '',
  lease_end: '',
  rent_amount: '',
  charges_amount: '',
  deposit: '',
  payment_day: 1,
  notes: '',
  ...(props.tenant || {}),
});
const saving = ref(false);

async function save() {
  saving.value = true;
  await attempt(async () => {
    const payload = { ...form, property_id: form.property_id || store.propertyId };
    const saved = props.tenant?.id ? await api.put(`/tenants/${props.tenant.id}`, payload) : await api.post('/tenants', payload);
    emit('saved', saved);
  }, 'Locataire enregistré');
  saving.value = false;
}
</script>
