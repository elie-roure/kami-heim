<template>
  <select :value="modelValue" @change="$emit('update:modelValue', Number($event.target.value))">
    <option v-for="y in years" :key="y" :value="y">{{ y }}</option>
  </select>
</template>

<script setup>
import { computed } from 'vue';

const props = defineProps({ modelValue: { type: Number, required: true }, future: { type: Number, default: 1 } });
defineEmits(['update:modelValue']);

const years = computed(() => {
  const now = new Date().getFullYear();
  const list = [];
  for (let y = now + props.future; y >= now - 20; y--) list.push(y);
  if (!list.includes(props.modelValue)) list.push(props.modelValue);
  return list.sort((a, b) => b - a);
});
</script>
