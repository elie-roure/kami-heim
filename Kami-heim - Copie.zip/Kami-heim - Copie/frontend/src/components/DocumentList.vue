<template>
  <div>
    <form class="card upload" @submit.prevent="upload">
      <h3>Ajouter un document</h3>
      <div class="form-grid">
        <label class="field full">
          <span>Fichier *</span>
          <input ref="fileInput" type="file" required @change="onFile" />
        </label>
        <label class="field">
          <span>Catégorie</span>
          <select v-model="form.category">
            <option v-for="(label, key) in store.meta.document_categories" :key="key" :value="key">{{ label }}</option>
          </select>
        </label>
        <label class="field"><span>Titre</span><input v-model="form.title" placeholder="Nom du fichier par défaut" /></label>
        <label class="field"><span>Date du document</span><input v-model="form.document_date" type="date" /></label>
        <label v-if="!tenantId" class="field">
          <span>Locataire concerné</span>
          <select v-model="form.tenant_id">
            <option value="">— Aucun (document du bien) —</option>
            <option v-for="t in tenants" :key="t.id" :value="t.id">{{ tenantName(t) }}</option>
          </select>
        </label>
        <label class="field full"><span>Notes</span><input v-model="form.notes" /></label>
      </div>
      <div class="toolbar" style="margin-top: 0.9rem">
        <button class="btn" type="submit" :disabled="uploading || !file">{{ uploading ? 'Envoi…' : '📤 Envoyer' }}</button>
      </div>
    </form>

    <div class="card">
      <div class="card-header">
        <h2>Documents ({{ filtered.length }})</h2>
        <select v-model="filter">
          <option value="">Toutes les catégories</option>
          <option v-for="(label, key) in store.meta.document_categories" :key="key" :value="key">{{ label }}</option>
        </select>
      </div>
      <div v-if="!filtered.length" class="empty">Aucun document</div>
      <div v-else class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Titre</th>
              <th>Catégorie</th>
              <th v-if="!tenantId">Locataire</th>
              <th>Date</th>
              <th class="num">Taille</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="d in filtered" :key="d.id">
              <td>
                <a :href="`/api/documents/${d.id}/file`" target="_blank" rel="noopener">{{ d.title }}</a>
                <div v-if="d.notes" class="help">{{ d.notes }}</div>
              </td>
              <td><span class="badge info">{{ store.meta.document_categories[d.category] || d.category }}</span></td>
              <td v-if="!tenantId">{{ d.tenant_last_name ? `${d.tenant_first_name || ''} ${d.tenant_last_name}` : '—' }}</td>
              <td>{{ date(d.document_date || d.uploaded_at) }}</td>
              <td class="num">{{ fileSize(d.size) }}</td>
              <td class="actions">
                <a class="btn ghost sm" :href="`/api/documents/${d.id}/file?download=1`">⬇ Télécharger</a>
                <button class="btn ghost danger sm" @click="remove(d)">Supprimer</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, reactive, ref } from 'vue';
import { api, qs } from '../api.js';
import { date, fileSize, tenantName } from '../format.js';
import { attempt, store } from '../store.js';

const props = defineProps({
  propertyId: { type: Number, required: true },
  tenantId: { type: Number, default: null },
  defaultCategory: { type: String, default: 'autre' },
});

const documents = ref([]);
const tenants = ref([]);
const filter = ref('');
const file = ref(null);
const fileInput = ref(null);
const uploading = ref(false);
const emptyForm = () => ({ category: props.defaultCategory, title: '', document_date: '', tenant_id: '', notes: '' });
const form = reactive(emptyForm());

const filtered = computed(() => documents.value.filter((d) => !filter.value || d.category === filter.value));

async function load() {
  await attempt(async () => {
    documents.value = await api.get(`/documents${qs({ property_id: props.propertyId, tenant_id: props.tenantId })}`);
    if (!props.tenantId) tenants.value = await api.get(`/tenants?property_id=${props.propertyId}`);
  });
}

function onFile(e) {
  file.value = e.target.files[0] || null;
}

async function upload() {
  if (!file.value) return;
  uploading.value = true;
  const data = new FormData();
  data.append('property_id', String(props.propertyId));
  const tenant = props.tenantId || form.tenant_id;
  if (tenant) data.append('tenant_id', String(tenant));
  for (const k of ['category', 'title', 'document_date', 'notes']) if (form[k]) data.append(k, form[k]);
  data.append('file', file.value);
  const ok = await attempt(() => api.post('/documents', data), 'Document ajouté');
  uploading.value = false;
  if (ok) {
    Object.assign(form, emptyForm());
    file.value = null;
    fileInput.value.value = '';
    load();
  }
}

async function remove(d) {
  if (!confirm(`Supprimer le document « ${d.title} » ?`)) return;
  if (await attempt(() => api.del(`/documents/${d.id}`), 'Document supprimé')) load();
}

onMounted(load);
</script>
