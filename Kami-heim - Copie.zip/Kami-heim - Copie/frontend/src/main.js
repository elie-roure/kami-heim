import { createApp } from 'vue';
import { Chart, registerables } from 'chart.js';
import App from './App.vue';
import router from './router.js';
import { init } from './store.js';
import './style.css';

Chart.register(...registerables);
Chart.defaults.font.family = "'Segoe UI', system-ui, -apple-system, Roboto, sans-serif";
Chart.defaults.color = '#475569';

init();
createApp(App).use(router).mount('#app');
