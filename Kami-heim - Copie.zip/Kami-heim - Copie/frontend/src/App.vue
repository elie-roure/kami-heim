<template>
  <div class="layout">
    <aside class="sidebar">
      <div class="brand"><img src="/favicon.svg" alt="" /> Kami-heim</div>
      <label for="property-select">Bien sélectionné</label>
      <select id="property-select" :value="store.propertyId ?? ''" @change="onPropertyChange">
        <option v-if="!store.properties.length" value="">Aucun bien</option>
        <option v-for="p in store.properties" :key="p.id" :value="p.id">{{ p.name }}</option>
      </select>
      <nav class="nav">
        <router-link v-for="item in nav" :key="item.to" :to="item.to" :class="{ active: isActive(item) }">
          <span class="icon">{{ item.icon }}</span>{{ item.label }}
        </router-link>
      </nav>
      <div class="spacer"></div>
      <div class="footer">Données stockées localement</div>
    </aside>

    <main class="main">
      <div v-if="!store.loaded" class="empty">Chargement…</div>
      <div v-else-if="needsProperty" class="card empty">
        <div class="big">🏠</div>
        <h2>Bienvenue dans Kami-heim</h2>
        <p>Commencez par créer votre premier bien immobilier.</p>
        <router-link class="btn" to="/biens">Créer un bien</router-link>
      </div>
      <router-view v-else :key="`${store.propertyId}-${route.fullPath}`" />
    </main>

    <div class="toasts">
      <div v-for="t in store.toasts" :key="t.id" class="toast" :class="t.type">{{ t.message }}</div>
    </div>
  </div>
</template>

<script setup>
import { computed } from 'vue';
import { useRoute } from 'vue-router';
import { setProperty, store } from './store.js';

const route = useRoute();

const nav = [
  { to: '/', label: 'Tableau de bord', icon: '📊' },
  { to: '/biens', label: 'Mes biens', icon: '🏠' },
  { to: '/locataires', label: 'Locataires', icon: '👤', prefix: true },
  { to: '/loyers', label: 'Loyers & quittances', icon: '💶' },
  { to: '/charges', label: 'Charges & syndic', icon: '🧾' },
  { to: '/regularisation', label: 'Régularisation', icon: '⚖️' },
  { to: '/pret', label: 'Prêt immobilier', icon: '🏦' },
  { to: '/documents', label: 'Documents', icon: '📁' },
  { to: '/parametres', label: 'Paramètres', icon: '⚙️' },
];

const isActive = (item) => item.prefix && route.path.startsWith(item.to);

const needsProperty = computed(() => !store.properties.length && !['properties', 'settings'].includes(route.name));

function onPropertyChange(e) {
  setProperty(Number(e.target.value) || null);
}
</script>
