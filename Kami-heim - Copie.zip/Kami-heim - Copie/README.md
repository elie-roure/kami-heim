# 🏠 Kami-heim — Gestion locative

Application web locale pour gérer un ou plusieurs biens mis en location :

| Fonction | Détail |
|---|---|
| **Biens** | Plusieurs biens possibles (adresse, surface, prix d'achat, frais de notaire…) avec sélecteur dans le menu |
| **Locataires** | Fiche locataire (bail, loyer, provision pour charges, dépôt de garantie) et dossier de documents (bail, état des lieux, pièce d'identité, justificatifs, assurance…) |
| **Loyers & quittances** | Suivi mensuel visuel (payé / partiel / impayé), saisie d'un paiement à une date donnée, saisie groupée du mois, **quittance PDF** (ou reçu si paiement partiel) avec montant en lettres et signature |
| **Charges & syndic** | Appels de fonds du syndic, taxe foncière, taxe d'habitation, assurance PNO, travaux… avec la **part récupérable** sur le locataire et la saisie récurrente (ex. 4 appels trimestriels) |
| **Régularisation annuelle** | Calcul automatique *charges réelles récupérables − provisions versées* au prorata de l'occupation, lignes modifiables, nouvelle provision proposée, **décompte PDF** à envoyer au locataire |
| **Prêt immobilier** | Calcul du tableau d'amortissement (capital, taux, durée, assurance) ou **import CSV** du tableau de la banque, graphiques capital restant dû / intérêts |
| **Tableau de bord** | Ce que le bien rapporte et coûte : loyers, charges, taxes, intérêts, cash-flow, résultat, rendement brut/net, impayés, graphiques mensuels et historique annuel, vue par bien ou tous biens confondus |
| **Sauvegarde** | Export zip (base + documents) depuis la page Paramètres |

Stack : **Vue 3 + Vite + Chart.js** (frontend) · **Node.js + Express + SQLite** (backend) · **PDFKit** (PDF) · **Docker**.

---

## 🚀 Démarrage avec Docker (recommandé)

Prérequis : [Docker Desktop](https://www.docker.com/products/docker-desktop/) (Windows / macOS) ou Docker Engine + plugin compose (Linux).

```bash
docker compose up -d --build
```

Puis ouvrez **http://localhost:8080**.

Sous Windows vous pouvez aussi double-cliquer sur `demarrer.bat` (ou `./demarrer.sh` sous Linux/macOS).

| Commande | Effet |
|---|---|
| `docker compose up -d --build` | construit et lance l'application |
| `docker compose down` | arrête l'application (les données sont conservées) |
| `docker compose logs -f` | affiche les journaux |

Pour changer le port : `KAMIHEIM_PORT=9000 docker compose up -d`.

### 📦 Où sont mes données ?

Tout est dans le dossier **`data/`** à côté du `docker-compose.yml` :

```
data/
├── kamiheim.db     ← base SQLite (biens, locataires, loyers, charges, prêts…)
└── uploads/        ← documents envoyés et signature
```

**Changer de PC** : copiez le dossier du projet (avec `data/`) sur l'autre machine puis lancez `docker compose up -d --build`.

**Sauvegarde** : bouton *Télécharger une sauvegarde* dans **Paramètres** (archive zip contenant `kamiheim.db` et `uploads/`).
Pour restaurer : arrêtez l'application, décompressez l'archive dans `data/`, relancez.

### 🔒 Accès depuis le réseau

L'application n'a pas d'authentification par défaut (usage local). Si vous l'exposez sur votre réseau,
décommentez `APP_USER` / `APP_PASSWORD` dans `docker-compose.yml` pour activer une authentification HTTP Basic.

---

## 🧭 Prise en main

1. **Paramètres** : renseignez vos nom et adresse de bailleur (et éventuellement une image de signature) — ils apparaissent sur les quittances.
2. **Mes biens** : créez votre bien (le prix d'achat sert au calcul du rendement).
3. **Locataires** : ajoutez le locataire avec son loyer hors charges et sa provision pour charges, puis déposez ses documents dans sa fiche.
4. **Loyers** : cliquez sur une case du mois pour enregistrer un paiement, puis téléchargez la quittance.
5. **Charges & syndic** : saisissez chaque appel de fonds / taxe avec sa part récupérable.
6. **Régularisation** : une fois par an, choisissez le locataire et l'année → ajustez → enregistrez → PDF.
7. **Prêt** : saisissez les caractéristiques du prêt ou importez le tableau de la banque.

### Format CSV du tableau d'amortissement

Une ligne d'en-tête, séparateur `;` (ou tabulation / virgule), dates `JJ/MM/AAAA` ou `AAAA-MM-JJ`, montants avec virgule ou point.
Les colonnes sont reconnues par leur nom (accents et majuscules ignorés) :

| Colonne | Noms reconnus | Obligatoire |
|---|---|---|
| Date d'échéance | contient « date » | ✅ |
| Capital amorti | « capital », « amortissement » | ✅ (ou mensualité) |
| Intérêts | contient « intérêt » | |
| Assurance | contient « assurance » | |
| Mensualité | « mensualité », « montant », « total » | |
| Capital restant dû | « restant », « CRD » | (calculé sinon) |
| N° | « n°», « numéro », « échéance » | |

Exemple :

```csv
N°;Date;Mensualité;Capital;Intérêts;Assurance;Capital restant dû
1;05/02/2024;1 180,61;577,28;583,33;20,00;199 422,72
2;05/03/2024;1 180,61;578,96;581,65;20,00;198 843,76
```

---

## 🛠️ Développement (sans Docker)

Prérequis : Node.js ≥ 20.

```bash
# Terminal 1 — API (port 3000, données dans backend/data)
cd backend
npm install
npm run dev

# Terminal 2 — interface (port 5173, proxy /api → 3000)
cd frontend
npm install
npm run dev
```

Tests du backend : `cd backend && npm test`.

### Structure

```
backend/
  src/server.js          serveur Express (API + fichiers statiques)
  src/db.js              schéma SQLite
  src/routes/            API : properties, tenants, documents, rents, expenses,
                         regularizations, loans, dashboard, settings
  src/pdf.js             quittances et décomptes de charges (PDFKit)
  src/loan.js            calcul et import des tableaux d'amortissement
  test/                  tests unitaires et test d'intégration de l'API
frontend/
  src/views/             pages Vue (tableau de bord, loyers, charges…)
  src/components/        composants réutilisables (modale, documents…)
Dockerfile               build multi-étapes (frontend + backend dans une seule image)
docker-compose.yml       lancement avec le volume ./data
```

### Variables d'environnement

| Variable | Défaut | Rôle |
|---|---|---|
| `PORT` | `3000` | port HTTP du serveur |
| `DATA_DIR` | `./data` (`/data` en Docker) | dossier de la base et des documents |
| `PUBLIC_DIR` | `../frontend/dist` (`/app/public` en Docker) | frontend compilé servi par Express |
| `APP_USER` / `APP_PASSWORD` | — | active l'authentification HTTP Basic |
| `TZ` | `Europe/Paris` | fuseau horaire |
